package gm.sajid.hn

import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/**
 * App Cloner স্ক্রিন (ওয়েব-ক্লোন নেই, শুধু আসল অ্যাপ ক্লোন):
 *  - প্রধান স্ক্রিন: ক্লোনগুলোর গ্রিড (নম্বর ব্যাজ সহ), নিচে "+" বাটন
 *  - ক্লোনে লং-প্রেস: Add / Create Shortcut / Rename / Delete / Change Icon
 *  - "+" চাপলে: ফোনের অ্যাপের তালিকা, একসাথে অনেকগুলো বেছে "Clone" চাপা যায়
 */
class CloneScreen(private val act: MainActivity) {
    private val orange = Color.parseColor("#FF9800")
    private val bg = Color.parseColor("#161616")
    private val tileBg = Color.parseColor("#262626")
    private val maxPick = 29

    private var grid: LinearLayout? = null
    private var emptyView: TextView? = null
    private val pendingDelete = HashSet<String>()

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ প্রধান স্ক্রিন ------------------------------------------------------------------
    fun show() {
        val d = object : Dialog(act, android.R.style.Theme_Black_NoTitleBar) {
            override fun onWindowFocusChanged(hasFocus: Boolean) {
                super.onWindowFocusChanged(hasFocus)
                if (hasFocus) refresh()
            }
        }
        d.window?.setBackgroundDrawable(ColorDrawable(bg))
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        d.window?.statusBarColor = bg

        val root = FrameLayout(act)
        root.setBackgroundColor(bg)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // উপরে বাঁ দিকে তিন ফোঁটা মেনু
        val dots = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        for (i in 0 until 3) {
            dots.addView(View(act).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(orange) } },
                LinearLayout.LayoutParams(dp(7), dp(7)).apply { rightMargin = dp(5) })
        }
        dots.setOnClickListener { showMenu() }
        col.addView(dots, LinearLayout.LayoutParams(-2, dp(52)))

        val g = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(18), dp(8), dp(110)) }
        grid = g
        val sv = ScrollView(act).apply { addView(g, ViewGroup.LayoutParams(-1, -2)) }
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val empty = TextView(act).apply {
            text = "No clones yet.\nTap + to clone an app.\n(Clones run inside this app; long-press > Install to install one)"
            textSize = 16f; setTextColor(Color.parseColor("#8A8A8A")); gravity = Gravity.CENTER
        }
        emptyView = empty
        root.addView(empty, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // নিচে মাঝে কমলা "+" বাটন
        val fab = TextView(act).apply {
            text = "+"; textSize = 34f; setTextColor(Color.parseColor("#1A1A1A")); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(orange) }
            elevation = dp(6).toFloat()
            setOnClickListener { showPicker() }
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(36) })

        d.setContentView(root)
        d.show()
        refresh()
    }

    private fun showMenu() {
        val items = arrayOf("Allow installing clones (Install unknown apps)", "Sign in with Google (pick this phone's account)", "Refresh")
        AlertDialog.Builder(act, R.style.PremiumDialog).setItems(items) { _, i ->
            when (i) {
                0 -> ApkCloneMgr.openInstallSettings(act)
                1 -> act.pickGoogleAccount { email ->
                    if (email != null) {
                        try { (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("email", email)) } catch (e: Throwable) { }
                        toast("$email copied — paste it on the clone's Google sign-in screen")
                    }
                }
                2 -> refresh()
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun refresh() {
        val g = grid ?: return
        // সিস্টেম থেকে আনইনস্টল হয়ে গেছে এমন (Delete করা) ক্লোন তালিকা থেকে সরাই
        for (c in ApkCloneMgr.load(act)) {
            if (c.pkg in pendingDelete && !ApkCloneMgr.isInstalled(act, c.pkg)) { ApkCloneMgr.forget(act, c.pkg); pendingDelete.remove(c.pkg) }
        }
        val list = ApkCloneMgr.load(act)
        val wl = WebCloneMgr.load(act)
        emptyView?.visibility = if (list.isEmpty() && wl.isEmpty()) View.VISIBLE else View.GONE
        val cells = ArrayList<View>()
        for (w in wl) {
            val cell = tile(webIcon(w), WebCloneMgr.numberOf(act, w).toString(), w.name, false, null)
            cell.setOnClickListener { openWeb(w) }
            cell.setOnLongClickListener { showWebSheet(w); true }
            cells.add(cell)
        }
        for (c in list) {
            val inst = ApkCloneMgr.isInstalled(act, c.pkg)
            val cell = tile(cloneIcon(c), ApkCloneMgr.numberOf(c.pkg).toString(), c.name, !inst, null)
            cell.setOnClickListener {
                if (inst) { if (!ApkCloneMgr.open(act, c.pkg)) toast("Couldn't open this clone") }
                else notInstalled(c)
            }
            cell.setOnLongClickListener { showSheet(c); true }
            cells.add(cell)
        }
        fillGrid(g, cells)
    }

    private fun notInstalled(c: ApkCloneMgr.ApkClone) {
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle(c.name).setMessage("This clone is not installed. Install it again?")
            .setPositiveButton("Install") { _, _ ->
                if (!ApkCloneMgr.isInstalled(act, c.orig)) toast("The original app isn't installed anymore")
                else cloneApps(listOf(Triple(c.orig, c.name, c.pkg as String?)))
            }
            .setNeutralButton("Remove") { _, _ -> ApkCloneMgr.forget(act, c.pkg); refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ গ্রিডের ঘর ------------------------------------------------------------------
    private fun fillGrid(box: LinearLayout, cells: List<View>) {
        box.removeAllViews()
        var i = 0
        while (i < cells.size) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until 5) {
                val v = cells.getOrNull(i + k) ?: View(act)
                row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
            i += 5
        }
    }

    private fun badge(text: String): TextView = TextView(act).apply {
        this.text = text; textSize = 10f; setTextColor(Color.parseColor("#1A1A1A")); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(orange) }
    }

    /** আইকন টাইল + নম্বর ব্যাজ + নাম। checked != null হলে বাছাইয়ের টিক-চিহ্ন দেখায় */
    private fun tile(icon: Drawable?, badgeText: String?, label: String, dim: Boolean, checked: Boolean?): LinearLayout {
        val cell = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val wrap = FrameLayout(act)
        val box = FrameLayout(act).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(15).toFloat(); setColor(tileBg)
                setStroke(dp(if (checked == true) 2 else 1), if (checked == true) orange else Color.parseColor("#363636"))
            }
        }
        val iv = ImageView(act).apply {
            if (icon != null) setImageDrawable(icon) else setImageResource(android.R.drawable.sym_def_app_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            if (dim) alpha = 0.4f
        }
        box.addView(iv, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.CENTER))
        wrap.addView(box, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
        if (badgeText != null) wrap.addView(badge(badgeText), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.START).apply { leftMargin = dp(0); topMargin = dp(0) })
        if (checked != null) {
            val ck = TextView(act).apply {
                gravity = Gravity.CENTER; textSize = 11f; typeface = Typeface.DEFAULT_BOLD
                if (checked) { text = "\u2713"; setTextColor(Color.parseColor("#1A1A1A")); background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(orange) } }
                else { text = ""; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#33000000")); setStroke(dp(2), Color.parseColor("#777777")) } }
            }
            wrap.addView(ck, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(2); bottomMargin = dp(2) })
        }
        cell.addView(wrap, LinearLayout.LayoutParams(dp(60), dp(60)))
        cell.addView(TextView(act).apply {
            text = label; textSize = 11f; setTextColor(if (dim) Color.parseColor("#777777") else Color.WHITE)
            gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(1), dp(4), dp(1), 0)
        }, LinearLayout.LayoutParams(-1, -2))
        return cell
    }

    // ------------------------------------------------------------------ আইকন ------------------------------------------------------------------
    private fun systemIcon(pkg: String): Drawable? = try { act.packageManager.getApplicationIcon(pkg) } catch (e: Throwable) { null }

    private fun customBitmap(c: ApkCloneMgr.ApkClone): Bitmap? {
        val f = ApkCloneMgr.iconFile(act, c.pkg)
        return if (f.exists()) try { BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null } else null
    }

    private fun cloneIcon(c: ApkCloneMgr.ApkClone): Drawable? {
        val b = customBitmap(c)
        if (b != null) return BitmapDrawable(act.resources, b)
        return systemIcon(c.pkg) ?: systemIcon(c.orig)
    }

    private fun saveSquareImage(uri: Uri, f: java.io.File): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var ss = 1
        while (bounds.outWidth / ss > 600 && bounds.outHeight / ss > 600) ss *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = ss }
        val bmp = act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) false else {
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        }
    } catch (e: Throwable) { false }

    /** হোম স্ক্রিন শর্টকাটের আইকন: নিজের ছবি থাকলে সেটা (গোল-কোণা), না থাকলে মূল আইকন + কোণায় ক্লোন নম্বর */
    private fun shortcutBitmap(c: ApkCloneMgr.ApkClone): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val custom = customBitmap(c)
        if (custom != null) {
            val path = Path().apply { addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.22f, size * 0.22f, Path.Direction.CW) }
            cv.clipPath(path)
            cv.drawBitmap(custom, null, RectF(0f, 0f, size.toFloat(), size.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
            return bmp
        }
        (systemIcon(c.pkg) ?: systemIcon(c.orig))?.let { it.setBounds(0, 0, size, size); it.draw(cv) }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = orange; cv.drawCircle(size * 0.8f, size * 0.8f, size * 0.19f, p)
        p.color = Color.parseColor("#1A1A1A"); p.textSize = size * 0.22f; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true
        cv.drawText(ApkCloneMgr.numberOf(c.pkg).toString(), size * 0.8f, size * 0.8f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }

    private fun shortcutInfo(c: ApkCloneMgr.ApkClone): ShortcutInfoCompat? {
        val li = ApkCloneMgr.launchIntent(act, c.pkg) ?: return null
        return ShortcutInfoCompat.Builder(act, "apkclone_" + c.pkg)
            .setShortLabel(c.name.take(24)).setLongLabel(c.name)
            .setIcon(IconCompat.createWithBitmap(shortcutBitmap(c)))
            .setIntent(li.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)).build()
    }

    private fun createShortcut(c: ApkCloneMgr.ApkClone) {
        try {
            val info = shortcutInfo(c) ?: run { toast("This clone isn't installed yet"); return }
            if (!ShortcutManagerCompat.isRequestPinShortcutSupported(act)) { toast("This launcher can't add shortcuts to the home screen"); return }
            ShortcutManagerCompat.requestPinShortcut(act, info, null)
            toast("Confirm \"Add\" in the home screen prompt")
        } catch (e: Throwable) { toast("Couldn't add to the home screen") }
    }

    private fun updateShortcut(c: ApkCloneMgr.ApkClone) {
        try { shortcutInfo(c)?.let { ShortcutManagerCompat.updateShortcuts(act, listOf(it)) } } catch (e: Throwable) { }
    }

    // ------------------------------------------------------------------ ইন-অ্যাপ (ইনস্টল ছাড়া) ক্লোন ------------------------------------------------------------------
    private fun webCustom(w: WebCloneMgr.WebClone): Bitmap? {
        val f = WebCloneMgr.iconFile(act, w.id)
        return if (f.exists()) try { BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null } else null
    }

    private fun webIcon(w: WebCloneMgr.WebClone): Drawable? {
        val b = webCustom(w)
        return if (b != null) BitmapDrawable(act.resources, b) else systemIcon(w.orig)
    }

    private fun openWeb(w: WebCloneMgr.WebClone) {
        try { act.startActivity(WebCloneMgr.launchIntent(act, w)) } catch (e: Throwable) { toast("Couldn't open this clone") }
    }

    private fun webShortcutBitmap(w: WebCloneMgr.WebClone): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val custom = webCustom(w)
        if (custom != null) {
            val path = Path().apply { addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.22f, size * 0.22f, Path.Direction.CW) }
            cv.clipPath(path)
            cv.drawBitmap(custom, null, RectF(0f, 0f, size.toFloat(), size.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
            return bmp
        }
        systemIcon(w.orig)?.let { it.setBounds(0, 0, size, size); it.draw(cv) }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = orange; cv.drawCircle(size * 0.8f, size * 0.8f, size * 0.19f, p)
        p.color = Color.parseColor("#1A1A1A"); p.textSize = size * 0.22f; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true
        cv.drawText(WebCloneMgr.numberOf(act, w).toString(), size * 0.8f, size * 0.8f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }

    private fun webShortcutInfo(w: WebCloneMgr.WebClone): ShortcutInfoCompat =
        ShortcutInfoCompat.Builder(act, "webclone_" + w.id)
            .setShortLabel(w.name.take(24)).setLongLabel(w.name)
            .setIcon(IconCompat.createWithBitmap(webShortcutBitmap(w)))
            .setIntent(WebCloneMgr.launchIntent(act, w)).build()

    private fun webShortcut(w: WebCloneMgr.WebClone) {
        try {
            if (!ShortcutManagerCompat.isRequestPinShortcutSupported(act)) { toast("This launcher can't add shortcuts to the home screen"); return }
            ShortcutManagerCompat.requestPinShortcut(act, webShortcutInfo(w), null)
            toast("Confirm \"Add\" in the home screen prompt")
        } catch (e: Throwable) { toast("Couldn't add to the home screen") }
    }

    private fun webShortcutUpdate(w: WebCloneMgr.WebClone) {
        try { ShortcutManagerCompat.updateShortcuts(act, listOf(webShortcutInfo(w))) } catch (e: Throwable) { }
    }

    private fun showWebSheet(w: WebCloneMgr.WebClone) {
        sheetOf(listOf<Pair<String, () -> Unit>>(
            "Open" to { openWeb(w) },
            "Install" to { installWeb(w) },
            "Add to Home screen" to { webShortcut(w) },
            "Rename" to { renameWeb(w) },
            "Delete" to { confirmDeleteWeb(w) },
            "Change Icon" to { changeIconWeb(w) }
        ))
    }

    /** "Install": আসল APK ক্লোন ফোনে ইনস্টল (ফোনে মূল অ্যাপ থাকতে হবে) */
    private fun installWeb(w: WebCloneMgr.WebClone) {
        if (!ApkCloneMgr.isInstalled(act, w.orig)) { toast("The original app isn't installed on this phone, so it can't be installed as a clone"); return }
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Install \"${w.name}\"?")
            .setMessage("This installs a real clone of the app on your phone (it will appear on the home screen / app list). The in-app clone stays too.")
            .setPositiveButton("Install") { _, _ -> cloneApps(listOf(Triple(w.orig, appLabel(w.orig), null as String?))) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renameWeb(w: WebCloneMgr.WebClone) {
        val et = EditText(act).apply { setSingleLine(true); setText(w.name); setSelection(text.length) }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(et)
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Rename").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { WebCloneMgr.rename(act, w.id, n); w.name = n; webShortcutUpdate(w); refresh() }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun confirmDeleteWeb(w: WebCloneMgr.WebClone) {
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Delete \"${w.name}\"?")
            .setMessage("The clone and its logins/data will be erased.")
            .setPositiveButton("Delete") { _, _ -> WebCloneMgr.remove(act, w.id); refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun changeIconWeb(w: WebCloneMgr.WebClone) {
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Change Icon")
            .setItems(arrayOf("Choose a picture", "Reset to original icon")) { _, i ->
                if (i == 0) {
                    act.pickImage { u ->
                        if (u != null) {
                            if (saveSquareImage(u, WebCloneMgr.iconFile(act, w.id))) { toast("Icon changed"); webShortcutUpdate(w); refresh() }
                            else toast("Couldn't use that picture")
                        }
                    }
                } else { WebCloneMgr.iconFile(act, w.id).delete(); webShortcutUpdate(w); refresh() }
            }.setNegativeButton("Cancel", null).show()
    }

    /** পিকারে "Clone": ইনস্টল ছাড়া ইন-অ্যাপ ক্লোন বানায় */
    private fun webCloneApps(items: List<Pair<String, String>>) {
        var made = 0
        val skipped = ArrayList<String>()
        for ((pkg, label) in items) { if (WebCloneMgr.add(act, pkg, label) != null) made++ else skipped.add(label) }
        refresh()
        if (made > 0) toast("$made clone(s) added. Tap to open, long-press for more")
        if (skipped.isNotEmpty()) {
            AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("No in-app version")
                .setMessage("These apps have no web version to run inside this app: " + skipped.joinToString(", ") +
                    ".\n\nA real clone of them can only be installed on the phone.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Install real clone") { _, _ ->
                    val ok = items.filter { it.second in skipped }.map { Triple(it.first, it.second, null as String?) }
                    cloneApps(ok)
                }.show()
        }
    }

    /** নিচ থেকে ওঠা মেনু (সারির তালিকা দিয়ে) */
    private fun sheetOf(rows: List<Pair<String, () -> Unit>>) {
        val sheet = Dialog(act)
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
            val r = dp(26).toFloat()
            background = GradientDrawable().apply { setColor(Color.parseColor("#262626")); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        for ((label, onClick) in rows) {
            box.addView(TextView(act).apply {
                text = label; textSize = 21f; setTextColor(orange); gravity = Gravity.CENTER
                setOnClickListener { sheet.dismiss(); onClick() }
            }, LinearLayout.LayoutParams(-1, dp(58)))
        }
        sheet.setContentView(box)
        sheet.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.setDimAmount(0.6f)
        }
        sheet.show()
    }

    // ------------------------------------------------------------------ লং-প্রেস মেনু (নিচ থেকে ওঠে) ------------------------------------------------------------------
    private fun showSheet(c: ApkCloneMgr.ApkClone) {
        val sheet = Dialog(act)
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
            val r = dp(26).toFloat()
            background = GradientDrawable().apply { setColor(Color.parseColor("#262626")); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
        }
        fun row(label: String, onClick: () -> Unit) {
            box.addView(TextView(act).apply {
                text = label; textSize = 21f; setTextColor(orange); gravity = Gravity.CENTER
                setOnClickListener { sheet.dismiss(); onClick() }
            }, LinearLayout.LayoutParams(-1, dp(58)))
        }
        row("Add") { cloneApps(listOf(Triple(c.orig, appLabel(c.orig), null as String?))) }
        row("Create Shortcut") { createShortcut(c) }
        row("Rename") { rename(c) }
        row("Delete") { confirmDelete(c) }
        row("Change Icon") { changeIcon(c) }
        sheet.setContentView(box)
        sheet.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.setDimAmount(0.6f)
        }
        sheet.show()
    }

    private fun appLabel(pkg: String): String = try {
        act.packageManager.getApplicationLabel(act.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Throwable) { pkg }

    private fun rename(c: ApkCloneMgr.ApkClone) {
        val et = EditText(act).apply { setSingleLine(true); setText(c.name); setSelection(text.length) }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(et)
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Rename").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    ApkCloneMgr.rename(act, c.pkg, n)
                    c.name = n
                    updateShortcut(c)
                    refresh()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun confirmDelete(c: ApkCloneMgr.ApkClone) {
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Delete \"${c.name}\"?")
            .setMessage("The clone and all of its data (logins, chats, files) will be erased.")
            .setPositiveButton("Delete") { _, _ ->
                if (ApkCloneMgr.isInstalled(act, c.pkg)) {
                    pendingDelete.add(c.pkg)
                    ApkCloneMgr.uninstall(act, c.pkg)       // সিস্টেম নিশ্চিত করবে; ফিরে এলে তালিকা নিজে হালনাগাদ হয়
                } else { ApkCloneMgr.forget(act, c.pkg); refresh() }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun changeIcon(c: ApkCloneMgr.ApkClone) {
        AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Change Icon")
            .setItems(arrayOf("Choose a picture", "Reset to original icon")) { _, i ->
                if (i == 0) {
                    act.pickImage { u ->
                        if (u != null) {
                            if (saveSquareImage(u, ApkCloneMgr.iconFile(act, c.pkg))) { toast("Icon changed"); updateShortcut(c); refresh() }
                            else toast("Couldn't use that picture")
                        }
                    }
                } else {
                    ApkCloneMgr.iconFile(act, c.pkg).delete()
                    updateShortcut(c); refresh()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------------ "+" : অ্যাপ বাছাই ------------------------------------------------------------------
    private fun showPicker() {
        val d = Dialog(act, android.R.style.Theme_Black_NoTitleBar)
        val pbg = Color.parseColor("#1C1C1C")
        d.window?.setBackgroundDrawable(ColorDrawable(pbg))
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        d.window?.statusBarColor = orange

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pbg) }

        val bar = FrameLayout(act).apply { setBackgroundColor(orange) }
        val back = TextView(act).apply {
            text = "\u2039"; textSize = 30f; setTextColor(orange); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#1A1A1A")) }
            setOnClickListener { d.dismiss() }
        }
        bar.addView(back, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER_VERTICAL or Gravity.START).apply { leftMargin = dp(16) })
        val title = TextView(act).apply { textSize = 22f; setTextColor(Color.parseColor("#1A1A1A")); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        bar.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(62)))

        root.addView(TextView(act).apply { text = "All"; textSize = 17f; setTextColor(orange); setPadding(dp(20), dp(14), dp(20), dp(6)) }, LinearLayout.LayoutParams(-2, -2))

        val g = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(12), dp(8), dp(16)) }
        val loading = TextView(act).apply { text = "Loading apps…"; textSize = 15f; setTextColor(Color.parseColor("#8A8A8A")); gravity = Gravity.CENTER; setPadding(0, dp(40), 0, 0) }
        g.addView(loading)
        root.addView(ScrollView(act).apply { addView(g, ViewGroup.LayoutParams(-1, -2)) }, LinearLayout.LayoutParams(-1, 0, 1f))

        val btn = TextView(act).apply { text = "Clone"; textSize = 22f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        root.addView(btn, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(24), dp(8), dp(24), dp(18)) })

        val picked = LinkedHashSet<String>()
        var apps: List<ApkCloneMgr.AppItem> = emptyList()
        var counts: Map<String, Int> = emptyMap()

        fun updateTop() {
            title.text = "Add  (${picked.size}/$maxPick)"
            val on = picked.isNotEmpty()
            btn.setTextColor(Color.parseColor("#1A1A1A"))
            btn.background = GradientDrawable().apply { cornerRadius = dp(27).toFloat(); setColor(if (on) orange else Color.parseColor("#5A5A5A")) }
        }

        fun fill() {
            val cells = ArrayList<View>()
            for (a in apps) {
                val sel = a.pkg in picked
                val cell = tile(a.icon, ((counts[a.pkg] ?: 0) + 1).toString(), a.label, false, sel)
                cell.setOnClickListener {
                    if (sel) picked.remove(a.pkg)
                    else if (picked.size >= maxPick) toast("You can pick up to $maxPick apps at a time")
                    else picked.add(a.pkg)
                    updateTop(); fill()
                }
                cells.add(cell)
            }
            fillGrid(g, cells)
        }

        btn.setOnClickListener {
            if (picked.isEmpty()) { toast("Select at least one app"); return@setOnClickListener }
            val chosen = apps.filter { it.pkg in picked }.map { it.pkg to it.label }
            d.dismiss()
            webCloneApps(chosen)
        }

        updateTop()
        d.setContentView(root)
        d.show()

        Thread {
            val list = try { ApkCloneMgr.listApps(act) } catch (e: Throwable) { emptyList() }
            val cnt = HashMap<String, Int>()
            for (c in ApkCloneMgr.load(act)) cnt[c.orig] = (cnt[c.orig] ?: 0) + 1
            act.runOnUiThread {
                apps = list; counts = cnt
                if (list.isEmpty()) loading.text = "No apps found" else fill()
            }
        }.start()
    }

    // ------------------------------------------------------------------ ক্লোন চালানো (একটার পর একটা) ------------------------------------------------------------------
    /** items: (মূল package, নাম, বিদ্যমান ক্লোনের package — নতুন হলে null) */
    private fun cloneApps(items: List<Triple<String, String, String?>>) {
        if (items.isEmpty()) return
        if (!ApkCloneMgr.canInstall(act)) {
            toast("Allow \"Install unknown apps\" for Sajid's Browser, then try again")
            ApkCloneMgr.openInstallSettings(act); return
        }
        val msg = TextView(act).apply { textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(24), dp(16), dp(24), dp(8)); text = "Preparing…" }
        val pd = AlertDialog.Builder(act, R.style.PremiumDialog).setTitle("Cloning").setView(msg).setCancelable(false).create()
        pd.show()
        fun next(i: Int) {
            if (i >= items.size) {
                try { pd.dismiss() } catch (e: Throwable) { }
                refresh()
                toast("Confirm each install on the system screen")
                return
            }
            val (orig, labelOrName, existing) = items[i]
            val name = if (existing != null) labelOrName else ApkCloneMgr.defaultName(act, orig, labelOrName)
            ApkCloneMgr.clone(act, orig, name, existing, { s -> msg.text = "(${i + 1}/${items.size}) $labelOrName\n$s" }, { _ -> next(i + 1) })
        }
        next(0)
    }
}
