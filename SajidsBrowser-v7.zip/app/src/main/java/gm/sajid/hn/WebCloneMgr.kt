package gm.sajid.hn

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * In-app clone (ইনস্টল ছাড়া): অ্যাপের ওয়েব-ভার্সন আলাদা লগইন/ডেটা নিয়ে অ্যাপের ভেতরেই চলে।
 * লং-প্রেস মেনুর "Install" দিলে তবেই আসল APK ক্লোন ফোনে ইনস্টল হয় (ApkCloneMgr)।
 */
object WebCloneMgr {
    class WebClone(val id: String, val orig: String, var name: String, val url: String, val desktop: Boolean)

    // অ্যাপ package -> (ওয়েব ঠিকানা, ডেস্কটপ-মোড লাগবে কিনা)
    private val sites: Map<String, Pair<String, Boolean>> = mapOf(
        "com.whatsapp" to ("https://web.whatsapp.com/" to true),
        "com.whatsapp.w4b" to ("https://web.whatsapp.com/" to true),
        "com.facebook.katana" to ("https://m.facebook.com/" to false),
        "com.facebook.lite" to ("https://m.facebook.com/" to false),
        "com.facebook.orca" to ("https://www.messenger.com/" to true),
        "com.instagram.android" to ("https://www.instagram.com/" to false),
        "org.telegram.messenger" to ("https://web.telegram.org/" to false),
        "org.thunderdog.challegram" to ("https://web.telegram.org/" to false),
        "com.google.android.youtube" to ("https://m.youtube.com/" to false),
        "com.google.android.gm" to ("https://mail.google.com/" to false),
        "com.twitter.android" to ("https://x.com/" to false),
        "com.zhiliaoapp.musically" to ("https://www.tiktok.com/" to false),
        "com.ss.android.ugc.trill" to ("https://www.tiktok.com/" to false),
        "com.snapchat.android" to ("https://web.snapchat.com/" to true),
        "com.linkedin.android" to ("https://www.linkedin.com/" to false),
        "com.reddit.frontpage" to ("https://www.reddit.com/" to false),
        "com.pinterest" to ("https://www.pinterest.com/" to false),
        "com.discord" to ("https://discord.com/app" to true),
        "com.spotify.music" to ("https://open.spotify.com/" to true),
        "com.netflix.mediclient" to ("https://www.netflix.com/" to false),
        "com.netflix.mediaclient" to ("https://www.netflix.com/" to false),
        "com.google.android.apps.maps" to ("https://www.google.com/maps" to false),
        "com.google.android.apps.photos" to ("https://photos.google.com/" to false),
        "com.google.android.apps.docs" to ("https://drive.google.com/" to false),
        "com.google.android.apps.messaging" to ("https://messages.google.com/web/" to true),
        "com.skype.raider" to ("https://web.skype.com/" to true),
        "com.microsoft.teams" to ("https://teams.microsoft.com/" to true),
        "com.amazon.mShop.android.shopping" to ("https://www.amazon.com/" to false),
        "com.github.android" to ("https://github.com/" to false),
        "com.openai.chatgpt" to ("https://chatgpt.com/" to false),
        "com.anthropic.claude" to ("https://claude.ai/" to false)
    )

    fun siteFor(pkg: String): Pair<String, Boolean>? = sites[pkg]

    private fun sp(c: Context) = c.getSharedPreferences("webclones", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<WebClone> {
        val out = ArrayList<WebClone>()
        try {
            val a = JSONArray(sp(c).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(WebClone(o.getString("id"), o.getString("orig"), o.getString("name"), o.getString("url"), o.optBoolean("desktop", false)))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun save(c: Context, l: List<WebClone>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("orig", it.orig).put("name", it.name).put("url", it.url).put("desktop", it.desktop)) }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun get(c: Context, id: String): WebClone? = load(c).firstOrNull { it.id == id }

    fun numberOf(c: Context, w: WebClone): Int = load(c).filter { it.orig == w.orig }.indexOfFirst { it.id == w.id } + 1

    /** নতুন ইন-অ্যাপ ক্লোন; ওয়েব-ভার্সন জানা না থাকলে null */
    fun add(c: Context, orig: String, label: String): WebClone? {
        val (url, desk) = siteFor(orig) ?: return null
        val l = load(c)
        val n = l.count { it.orig == orig } + 1
        val w = WebClone("w" + java.lang.Long.toString(System.currentTimeMillis(), 36) + n, orig, "$label($n)", url, desk)
        l.add(w); save(c, l)
        return w
    }

    fun rename(c: Context, id: String, name: String) { val l = load(c); l.firstOrNull { it.id == id }?.name = name; save(c, l) }

    fun iconFile(c: Context, id: String) = File(c.filesDir, "wcicon_$id.png")

    fun remove(c: Context, id: String) {
        save(c, load(c).filter { it.id != id })
        try { iconFile(c, id).delete() } catch (e: Exception) { }
        try {
            val s = Class.forName("androidx.webkit.ProfileStore").getMethod("getInstance").invoke(null)
            s?.javaClass?.getMethod("deleteProfile", String::class.java)?.invoke(s, profileName(id))
        } catch (e: Throwable) { }
    }

    fun profileName(id: String) = "wc_$id"

    /** WebView-কে এই ক্লোনের আলাদা স্টোরেজে বসায়; ফোনের WebView সাপোর্ট না করলে false */
    fun applyProfile(web: WebView, id: String): Boolean = try {
        if (androidx.webkit.WebViewFeature.isFeatureSupported("MULTI_PROFILE")) {
            Class.forName("androidx.webkit.WebViewCompat").getMethod("setProfile", WebView::class.java, String::class.java).invoke(null, web, profileName(id))
            true
        } else false
    } catch (e: Throwable) { false }

    fun cookieMgr(id: String): CookieManager {
        try {
            val s = Class.forName("androidx.webkit.ProfileStore").getMethod("getInstance").invoke(null)
            if (s != null) {
                val p = s.javaClass.getMethod("getOrCreateProfile", String::class.java).invoke(s, profileName(id))
                if (p != null) return p.javaClass.getMethod("getCookieManager").invoke(p) as CookieManager
            }
        } catch (e: Throwable) { }
        return CookieManager.getInstance()
    }

    fun launchIntent(c: Context, w: WebClone): Intent =
        Intent(c, WebCloneActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse("webclone://" + w.id))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
