package gm.sajid.hn

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

// ============================================================================
// Sajid's Browser — নিজস্ব ডাউনলোড ইঞ্জিন (ফোনের DownloadManager ব্যবহার করে না)
//  • Pause / Resume / Cancel / Retry — সব ব্রাউজারের ভেতর থেকেই
//  • DlService (ফোরগ্রাউন্ড সার্ভিস + WakeLock) চলে, তাই অ্যাপ ব্যাকগ্রাউন্ডে গেলেও ডাউনলোড চলে
//  • নেট চলে গেলে নিজে নিজে আবার চেষ্টা করে এবং যেখানে থেমেছিল সেখান থেকে চালায় (HTTP Range)
//  • অ্যাপ বন্ধ/কিল হলেও অসমাপ্ত ডাউনলোড মনে রাখে, পরেরবার অ্যাপ খুললে নিজে আবার চালু হয়
// ============================================================================

class DlTask(
    val id: String, val url: String, var name: String, var mime: String,
    val ua: String, val cookie: String, val referer: String, val created: Long
) {
    @Volatile var state = DlEngine.QUEUED
    @Volatile var total = -1L
    @Volatile var done = 0L
    @Volatile var speed = 0L
    @Volatile var error = ""
    @Volatile var uri = ""
    @Volatile var etag = ""
    @Volatile var pause = false
    @Volatile var cancel = false
    @Volatile var conn: HttpURLConnection? = null
    var active = false      // কোনো থ্রেড এখন এটা চালাচ্ছে কিনা (t এর lock এ পড়া/লেখা)
    var rerun = false       // চলার সময় Resume চাপা হলে শেষে আবার চালানোর জন্য
}

private class FatalDl(msg: String) : Exception(msg)

object DlEngine {
    const val QUEUED = 0
    const val RUNNING = 1
    const val PAUSED = 2
    const val WAITING = 3      // নেটের জন্য অপেক্ষা
    const val FAILED = 4
    const val DONE = 5
    const val SAVING = 6       // শেষ হয়ে Downloads ফোল্ডারে সেভ হচ্ছে

    private const val K = "dlTasks"
    private const val MAX_RETRY = 30

    private val lock = Any()
    private val tasks = ArrayList<DlTask>()
    private var loaded = false
    @Volatile private var app: Context? = null
    private val pool = Executors.newFixedThreadPool(3)   // একসাথে সর্বোচ্চ ৩টা ডাউনলোড, বাকিগুলো লাইনে

    // ডাউনলোড শেষ হলে বা ফেল করলে (ওয়ার্কার থ্রেডে) ডাকা হয়
    @Volatile var listener: ((DlTask) -> Unit)? = null

    private fun sp(c: Context) = c.getSharedPreferences("browser", Context.MODE_PRIVATE)

    private fun partDir(c: Context): File {
        val d = File(c.getExternalFilesDir(null) ?: c.filesDir, "dl")
        d.mkdirs()
        return d
    }
    private fun partFile(c: Context, t: DlTask) = File(partDir(c), t.id + ".part")

    // ---------- শুরু / লোড ----------
    fun attach(c: Context) {
        val ctx = c.applicationContext
        val resume = ArrayList<DlTask>()
        synchronized(lock) {
            app = ctx
            if (loaded) return
            loaded = true
            try {
                val a = JSONArray(sp(ctx).getString(K, "[]"))
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val t = DlTask(o.getString("id"), o.getString("u"), o.optString("n"), o.optString("m"),
                        o.optString("ua"), o.optString("ck"), o.optString("rf"), o.optLong("cr"))
                    t.total = o.optLong("tot", -1L)
                    t.etag = o.optString("et")
                    t.error = o.optString("err")
                    val p = partFile(ctx, t)
                    t.done = if (p.exists()) p.length() else 0L
                    when (o.optInt("st", PAUSED)) {
                        FAILED -> t.state = FAILED
                        PAUSED -> t.state = PAUSED
                        else -> { t.state = QUEUED; resume.add(t) }   // অ্যাপ কিল হওয়ার সময় যেগুলো চলছিল, সেগুলো নিজে চালু হবে
                    }
                    tasks.add(t)
                }
            } catch (e: Exception) { }
        }
        resume.forEach { submit(ctx, it) }
    }

    fun list(c: Context): List<DlTask> {
        attach(c)
        return synchronized(lock) { ArrayList(tasks) }
    }

    fun get(id: String): DlTask? = synchronized(lock) { tasks.firstOrNull { it.id == id } }

    private fun save() {
        val c = app ?: return
        try {
            val a = JSONArray()
            synchronized(lock) {
                for (t in tasks) {
                    a.put(JSONObject().put("id", t.id).put("u", t.url).put("n", t.name).put("m", t.mime)
                        .put("ua", t.ua).put("ck", t.cookie).put("rf", t.referer).put("cr", t.created)
                        .put("st", t.state).put("tot", t.total).put("et", t.etag).put("err", t.error))
                }
            }
            sp(c).edit().putString(K, a.toString()).apply()
        } catch (e: Exception) { }
    }

    // ---------- বাইরের API ----------
    fun start(c: Context, url: String, name: String, mime: String, ua: String, cookie: String, referer: String): DlTask {
        attach(c)
        val t = DlTask("t" + System.nanoTime(), url, name, mime, ua, cookie, referer, System.currentTimeMillis())
        synchronized(lock) { tasks.add(0, t) }
        save()
        submit(c.applicationContext, t)
        return t
    }

    fun pause(c: Context, t: DlTask) {
        t.pause = true
        if (t.state == QUEUED || t.state == RUNNING || t.state == WAITING) { t.state = PAUSED; t.speed = 0L }
        abort(t)
        save()
    }

    fun resume(c: Context, t: DlTask) {
        if (t.state != PAUSED && t.state != FAILED) return
        t.pause = false; t.cancel = false; t.error = ""; t.state = QUEUED
        save()
        submit(c.applicationContext, t)
    }

    fun cancel(c: Context, t: DlTask) {
        t.cancel = true
        abort(t)
        val idle = synchronized(t) { !t.active }
        if (idle) cleanup(c.applicationContext, t)
    }

    fun pauseAll(c: Context) { list(c).forEach { if (it.state == QUEUED || it.state == RUNNING || it.state == WAITING) pause(c, it) } }
    fun resumeAll(c: Context) { list(c).forEach { if (it.state == PAUSED || it.state == FAILED) resume(c, it) } }

    fun hasActive(c: Context): Boolean = list(c).any { it.state == QUEUED || it.state == RUNNING || it.state == WAITING || it.state == SAVING }

    // চলতে থাকা কানেকশন বন্ধ করে দেয়, যাতে Pause/Cancel সঙ্গে সঙ্গে কাজ করে (মেইন থ্রেডে নেটওয়ার্ক বন্ধ না করতে আলাদা থ্রেড)
    private fun abort(t: DlTask) {
        val cn = t.conn ?: return
        Thread { try { cn.disconnect() } catch (e: Throwable) { } }.start()
    }

    // ---------- চালানো ----------
    private fun submit(c: Context, t: DlTask) {
        synchronized(t) {
            if (t.active) { t.rerun = true; return }
            t.active = true
        }
        DlService.begin(c, t.name)
        pool.execute {
            try {
                var again: Boolean
                do {
                    try { work(c, t) } catch (e: Throwable) { fail(c, t, e.message ?: e.javaClass.simpleName) }
                    again = false
                    synchronized(t) {
                        if (t.rerun && !t.cancel && t.state != DONE) { t.rerun = false; again = true } else { t.rerun = false; t.active = false }
                    }
                } while (again)
            } finally {
                DlService.end(c)
            }
        }
    }

    private fun setState(t: DlTask, s: Int) {
        if (t.state == DONE) return
        t.state = s
        if (s == RUNNING) t.error = ""
        if (s != RUNNING && s != WAITING) t.speed = 0L
        save()
    }

    private fun work(c: Context, t: DlTask) {
        if (t.state == DONE) return
        if (t.cancel) { cleanup(c, t); return }
        if (t.pause) { setState(t, PAUSED); return }
        var attempt = 0
        while (true) {
            if (t.cancel) { cleanup(c, t); return }
            if (t.pause) { setState(t, PAUSED); return }
            setState(t, RUNNING)
            val startDone = t.done
            var finished = false
            try {
                finished = transfer(c, t)
            } catch (e: FatalDl) {
                if (t.cancel) { cleanup(c, t); return }
                fail(c, t, e.message ?: "Error"); return
            } catch (e: IOException) {
                if (t.cancel) { cleanup(c, t); return }
                if (t.pause) { setState(t, PAUSED); return }
                if (t.done > startDone) attempt = 0
                attempt++
                if (attempt > MAX_RETRY) { fail(c, t, "Network problem: " + (e.message ?: "connection lost")); return }
                t.speed = 0L; t.error = "Waiting for network…"
                setState(t, WAITING)
                var wait = minOf(30000L, 1500L * (1 shl minOf(attempt, 4)))
                while (wait > 0 && !t.pause && !t.cancel) {
                    try { Thread.sleep(500) } catch (x: InterruptedException) { }
                    wait -= 500
                }
                continue
            }
            if (finished) { finish(c, t); return }
            // পুরোটা শেষ হয়নি: Pause/Cancel হয়েছে — লুপের মাথায় গিয়ে সেটা সামলানো হবে
        }
    }

    // true = পুরো ফাইল নামানো হয়েছে; false = Pause/Cancel এর কারণে থেমেছে
    private fun transfer(c: Context, t: DlTask): Boolean {
        val part = partFile(c, t)
        var have = if (part.exists()) part.length() else 0L
        if (t.total > 0 && have >= t.total) { t.done = have; return true }

        var curUrl = t.url
        val origHost = try { URL(t.url).host } catch (e: Exception) { "" }
        var cookie: String? = t.cookie.ifBlank { null }
        var hops = 0
        var cn0: HttpURLConnection? = null
        while (true) {
            val u = URL(curUrl)
            val x = u.openConnection() as HttpURLConnection
            x.connectTimeout = 20000; x.readTimeout = 30000
            x.instanceFollowRedirects = false
            x.setRequestProperty("User-Agent", t.ua.ifBlank { "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36" })
            x.setRequestProperty("Accept-Encoding", "identity")
            x.setRequestProperty("Accept", "*/*")
            if (cookie != null) x.setRequestProperty("Cookie", cookie)
            if (t.referer.isNotBlank()) x.setRequestProperty("Referer", t.referer)
            if (have > 0) {
                x.setRequestProperty("Range", "bytes=$have-")
                if (t.etag.isNotBlank()) x.setRequestProperty("If-Range", t.etag)
            }
            t.conn = x
            if (t.cancel || t.pause) { try { x.disconnect() } catch (e: Throwable) { }; return false }
            val code = x.responseCode
            if (code in 300..399 && code != 304) {
                val loc = x.getHeaderField("Location")
                try { x.disconnect() } catch (e: Throwable) { }
                if (loc.isNullOrBlank() || ++hops > 10) throw FatalDl("Too many redirects")
                curUrl = URL(u, loc).toString()
                val nh = try { URL(curUrl).host } catch (e: Exception) { "" }
                cookie = if (nh == origHost) t.cookie.ifBlank { null } else CookieManager.getInstance().getCookie(curUrl)
                continue
            }
            cn0 = x
            break
        }
        val cn = cn0 ?: throw IOException("no connection")

        val code = cn.responseCode
        when {
            code == 200 || code == 206 -> { }
            code == 416 -> {
                try { cn.disconnect() } catch (e: Throwable) { }
                if (have > 0 && t.total > 0 && have == t.total) { t.done = have; return true }
                part.delete(); t.done = 0L; t.etag = ""
                if (have == 0L) throw FatalDl("Server refused the download (HTTP 416)")
                return transfer(c, t)
            }
            code == 408 || code == 429 || code >= 500 -> {
                try { cn.disconnect() } catch (e: Throwable) { }
                throw IOException("Server busy (HTTP $code)")
            }
            else -> {
                try { cn.disconnect() } catch (e: Throwable) { }
                throw FatalDl("Server refused the download (HTTP $code). The link may have expired — open the page again and retry.")
            }
        }
        val ct = (cn.contentType ?: "").substringBefore(";").trim().lowercase()
        if (ct.startsWith("text/html") && !t.mime.startsWith("text/html", true)) {
            try { cn.disconnect() } catch (e: Throwable) { }
            throw FatalDl("The server sent a web page instead of the file (link expired, or login needed).")
        }

        val append = code == 206 && have > 0
        if (!append) { have = 0L; if (part.exists()) part.delete() }
        val clen = cn.contentLengthLong
        val total = when {
            code == 206 -> {
                val cr = cn.getHeaderField("Content-Range") ?: ""
                val tt = cr.substringAfter('/', "").trim().toLongOrNull()
                tt ?: (if (clen > 0) have + clen else -1L)
            }
            clen > 0 -> clen
            else -> -1L
        }
        t.total = total
        val et = cn.getHeaderField("ETag")
        val lm = cn.getHeaderField("Last-Modified")
        if (!append || t.etag.isBlank()) t.etag = if (!et.isNullOrBlank() && !et.startsWith("W/")) et else (lm ?: "")

        if (total > 0) {
            val dir = part.parentFile
            if (dir != null && dir.usableSpace < (total - have) + 50L * 1024 * 1024) {
                try { cn.disconnect() } catch (e: Throwable) { }
                throw FatalDl("Not enough storage space on the phone")
            }
        }

        var got = have
        t.done = got
        val buf = ByteArray(64 * 1024)
        var winStart = System.currentTimeMillis(); var winBytes = 0L; var lastSave = winStart
        FileOutputStream(part, append).use { out ->
            cn.inputStream.use { ins ->
                while (true) {
                    if (t.cancel || t.pause) { out.flush(); try { cn.disconnect() } catch (e: Throwable) { }; return false }
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    got += n; winBytes += n; t.done = got
                    val now = System.currentTimeMillis()
                    if (now - winStart >= 1000) {
                        t.speed = winBytes * 1000 / (now - winStart); winStart = now; winBytes = 0L
                        publish(c)
                    }
                    if (now - lastSave > 5000) { save(); lastSave = now }
                }
                out.flush()
            }
        }
        try { cn.disconnect() } catch (e: Throwable) { }
        if (t.total > 0 && got < t.total) throw IOException("Connection closed early")
        if (t.total <= 0) t.total = got
        t.done = got
        return true
    }

    // সব চলমান ডাউনলোডের মোট প্রগ্রেস নোটিফিকেশনে
    private fun publish(c: Context) {
        val run = synchronized(lock) { tasks.filter { it.state == RUNNING || it.state == WAITING } }
        if (run.isEmpty()) return
        var tot = 0L; var dn = 0L; var spd = 0L
        for (x in run) { if (x.total > 0) { tot += x.total; dn += x.done }; spd += x.speed }
        val pct = if (tot > 0) (dn * 100 / tot).toInt() else -1
        val parts = ArrayList<String>()
        if (pct >= 0) parts.add("$pct%")
        if (spd > 0) parts.add(fmtSpeed(spd))
        val title = if (run.size == 1) run[0].name else "${run.size} downloads"
        DlService.status(c, title, if (parts.isEmpty()) "Downloading…" else parts.joinToString("  •  "), pct)
    }

    fun fmtSpeed(b: Long): String = when {
        b < 1024L -> "$b B/s"
        b < 1024L * 1024 -> String.format("%.0f KB/s", b / 1024.0)
        else -> String.format("%.1f MB/s", b / 1048576.0)
    }

    // ---------- শেষ / ব্যর্থ / বাতিল ----------
    private fun mimeFor(t: DlTask): String {
        var m = t.mime
        if (m.isBlank() || m.contains("octet", true)) {
            m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.name.substringAfterLast('.', "").lowercase()) ?: m
        }
        return if (m.isBlank()) "application/octet-stream" else m
    }

    private fun finish(c: Context, t: DlTask) {
        setState(t, SAVING)
        val part = partFile(c, t)
        try {
            if (!part.exists()) throw IOException("temporary file is missing")
            if (t.total <= 0) t.total = part.length()
            val mime = mimeFor(t)
            val u = saveToPublic(c, t.name, mime, part)
            part.delete()
            t.uri = u.toString()
            t.done = maxOf(t.done, t.total)
            t.state = DONE; t.speed = 0L
            synchronized(lock) { tasks.remove(t) }
            DlStore.add(c, DlRec("e" + t.id, t.name, t.url, mime, System.currentTimeMillis(), t.uri, -1L))
            save()
            DlService.finished(c, t.name, shareable(c, u), mime, null)
            try { listener?.invoke(t) } catch (e: Throwable) { }
        } catch (e: Throwable) {
            fail(c, t, "Couldn't save the file: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    private fun fail(c: Context, t: DlTask, msg: String) {
        if (t.state == DONE) return
        t.error = msg
        setState(t, FAILED)
        DlService.finished(c, t.name, null, "", msg)
        try { listener?.invoke(t) } catch (e: Throwable) { }
    }

    private fun cleanup(c: Context, t: DlTask) {
        try { partFile(c, t).delete() } catch (e: Throwable) { }
        synchronized(lock) { tasks.remove(t) }
        save()
    }

    // ব্যর্থ/শেষ ডাউনলোড তালিকা থেকে সরানো (অসমাপ্ত ফাইলও মোছে)
    fun remove(c: Context, t: DlTask) {
        t.cancel = true
        abort(t)
        cleanup(c.applicationContext, t)
    }

    // ---------- Downloads ফোল্ডারে সেভ ----------
    private fun saveToPublic(c: Context, name: String, mime: String, src: File): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val u = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("couldn't create a file in Downloads")
            try {
                c.contentResolver.openOutputStream(u)!!.use { o -> src.inputStream().use { it.copyTo(o, 256 * 1024) } }
                val ok = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                c.contentResolver.update(u, ok, null, null)
            } catch (e: Throwable) {
                try { c.contentResolver.delete(u, null, null) } catch (x: Throwable) { }
                throw e
            }
            return u
        }
        val d = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: c.filesDir
        d.mkdirs()
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var f = File(d, name); var i = 1
        while (f.exists()) { f = File(d, "$base ($i)$ext"); i++ }
        src.copyTo(f, false)
        return Uri.fromFile(f)
    }

    // নোটিফিকেশনে ফাইল খুলতে file:// uri চলে না — FileProvider uri
    private fun shareable(c: Context, u: Uri): Uri {
        if (u.scheme != "file") return u
        return try { androidx.core.content.FileProvider.getUriForFile(c, c.packageName + ".fileprovider", File(u.path!!)) } catch (e: Exception) { u }
    }
}
