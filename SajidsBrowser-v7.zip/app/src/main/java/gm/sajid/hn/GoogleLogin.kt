package gm.sajid.hn

import android.net.Uri

/**
 * "Continue with Google" / Google sign-in: যেকোনো সাইট accounts.google.com-এ পাঠালে আগে ফোনের গুগল অ্যাকাউন্টের তালিকা দেখানো হয়,
 * বাছা ইমেইল login_hint হিসেবে বসিয়ে গুগলের লগইন পেজ খোলা হয়।
 */
object GoogleLogin {
    /** একই ট্যাবে বারবার জিজ্ঞেস না করার সময় (লগইনের মাঝের ধাপগুলো যেন আবার না আটকায়) */
    const val QUIET_MS = 180_000L

    private val entry = listOf(
        "/o/oauth2/v2/auth", "/o/oauth2/auth", "/gsi/select", "/ServiceLogin", "/AccountChooser", "/v3/signin/identifier"
    )

    /** এটা কি গুগল সাইন-ইনের শুরুর ধাপ (এবং আগে থেকে ইমেইল বাছা নেই)? */
    fun shouldAsk(u: Uri): Boolean {
        if (u.host != "accounts.google.com") return false
        val p = u.path ?: return false
        if (entry.none { p == it || p.startsWith("$it/") }) return false
        if (!u.getQueryParameter("login_hint").isNullOrBlank()) return false
        if (!u.getQueryParameter("Email").isNullOrBlank()) return false
        return true
    }

    /** url-এ login_hint (এবং পুরোনো ServiceLogin-এর জন্য Email) বসায়, আগে থাকলে বদলে দেয় */
    fun withHint(url: String, email: String): String {
        val u = Uri.parse(url)
        val b = u.buildUpon().clearQuery()
        for (k in u.queryParameterNames) {
            if (k == "login_hint" || k == "Email") continue
            for (v in u.getQueryParameters(k)) b.appendQueryParameter(k, v)
        }
        b.appendQueryParameter("login_hint", email)
        val p = u.path ?: ""
        if (p.startsWith("/ServiceLogin") || p.startsWith("/AccountChooser")) b.appendQueryParameter("Email", email)
        return b.build().toString()
    }
}
