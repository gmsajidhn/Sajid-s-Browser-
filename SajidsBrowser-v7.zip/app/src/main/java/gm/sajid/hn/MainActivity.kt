package gm.sajid.hn

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// Sajid's Browser: অ্যাপে ঢুকলেই হোম পেজ (সার্চ + শর্টকাট) দেখায়, বাকি সব BrowserLayer এ।
class MainActivity : AppCompatActivity() {
    var browser: BrowserLayer? = null

    // ===== BrowserLayer যে সার্ভিসগুলো চায় =====
    // কুকি/সাইট সেটিং মোছার সময় ব্রাউজার শুধু নিজের ডাটা মোছে; এখানে আলাদা অ্যাপ-ডাটা নেই, তাই সরাসরি চালানো
    fun keepAppDataWhile(action: () -> Unit) {
        runOnUiThread { try { action() } catch (e: Exception) { } }
    }

    private var imageCb: ((Uri?) -> Unit)? = null
    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = imageCb; imageCb = null; cb?.invoke(uri)
    }
    // প্রোফাইল ছবি / শর্টকাট আইকন / হোম ব্যাকগ্রাউন্ডের জন্য ছবি বাছাই
    fun pickImage(cb: (Uri?) -> Unit) {
        imageCb = cb
        try { imagePicker.launch("image/*") } catch (e: Exception) { imageCb = null; cb(null) }
    }

    // ফোনে লগইন থাকা গুগল অ্যাকাউন্টের তালিকা থেকে একটা বাছা (সিস্টেমের নিজের পিকার, কোনো পারমিশন লাগে না)
    private var acctCb: ((String?) -> Unit)? = null
    private val acctPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = acctCb; acctCb = null
        cb?.invoke(if (r.resultCode == RESULT_OK) r.data?.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME) else null)
    }
    @Suppress("DEPRECATION")
    fun pickGoogleAccount(cb: (String?) -> Unit) {
        acctCb = cb
        try { acctPicker.launch(android.accounts.AccountManager.newChooseAccountIntent(null, null, arrayOf("com.google"), false, null, null, null, null)) }
        catch (e: Exception) { acctCb = null; Toast.makeText(this, "Couldn't open the account list", Toast.LENGTH_SHORT).show(); cb(null) }
    }

    // Lens: ক্যামেরায় ছবি তোলা
    private var camCb: ((Uri?) -> Unit)? = null
    private var camUri: Uri? = null
    private val camLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val cb = camCb; camCb = null; cb?.invoke(if (ok) camUri else null)
    }
    fun takePhoto(cb: (Uri?) -> Unit) {
        requestPerms(arrayOf(Manifest.permission.CAMERA), true) { granted ->
            if (!granted) { Toast.makeText(this, "Camera permission is needed to take a photo", Toast.LENGTH_SHORT).show(); cb(null); return@requestPerms }
            try {
                val dir = java.io.File(cacheDir, "lens").apply { mkdirs() }
                val f = java.io.File.createTempFile("shot", ".jpg", dir)
                val u = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                camUri = u; camCb = cb; camLauncher.launch(u)
            } catch (e: Exception) { camCb = null; cb(null) }
        }
    }

    // এক্সটেনশন ফাইল বাছাই
    private var docCb: ((Uri?, String) -> Unit)? = null
    private val docPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val cb = docCb; docCb = null
        var n = ""
        if (uri != null) try { contentResolver.query(uri, null, null, null, null)?.use { c -> val ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && ix >= 0) n = c.getString(ix) ?: "" } } catch (e: Exception) { }
        cb?.invoke(uri, n)
    }
    fun pickDoc(cb: (Uri?, String) -> Unit) { docCb = cb; try { docPicker.launch(arrayOf("*/*")) } catch (e: Exception) { docCb = null; cb(null, "") } }

    // ফাইল সেভ করার জায়গা বাছাই (বুকমার্ক এক্সপোর্ট: Drive / Downloads / যেকোনো জায়গায়)
    private var createCb: ((Uri?) -> Unit)? = null
    private val docCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val cb = createCb; createCb = null; cb?.invoke(uri)
    }
    fun createDoc(name: String, cb: (Uri?) -> Unit) { createCb = cb; try { docCreator.launch(name) } catch (e: Exception) { createCb = null; cb(null) } }

    // সেভ করা পাসওয়ার্ড দেখার আগে ফোনের লক (পিন/প্যাটার্ন/ফিঙ্গারপ্রিন্ট) যাচাই
    private var lockCb: ((Boolean) -> Unit)? = null
    private val lockLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = lockCb; lockCb = null; cb?.invoke(r.resultCode == android.app.Activity.RESULT_OK)
    }
    fun confirmDeviceLock(title: String, cb: (Boolean) -> Unit) {
        try {
            val km = getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (!km.isDeviceSecure) { cb(true); return }
            val i = km.createConfirmDeviceCredentialIntent(title, null)
            if (i == null) { cb(true); return }
            lockCb = cb; lockLauncher.launch(i)
        } catch (e: Exception) { lockCb = null; cb(false) }
    }

    // ওয়েবসাইটের ফাইল আপলোড
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    fun pickFile(cb: ValueCallback<Array<Uri>>, intent: Intent): Boolean {
        fileCb?.onReceiveValue(null); fileCb = cb
        return try { chooser.launch(intent); true } catch (e: Exception) { fileCb = null; false }
    }

    // সাইট চাইলে লোকেশন/ক্যামেরা/মাইক পারমিশন (all=true হলে সবগুলো লাগবে, নইলে একটা হলেই চলবে)
    private var permCb: ((Boolean) -> Unit)? = null
    private var permAll = true
    private var permList: Array<String> = emptyArray()
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val cb = permCb; permCb = null
        val ok = if (permAll) permList.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
                 else permList.any { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        cb?.invoke(ok)
    }
    fun requestPerms(perms: Array<String>, all: Boolean, cb: (Boolean) -> Unit) {
        fun granted(x: String) = ContextCompat.checkSelfPermission(this, x) == PackageManager.PERMISSION_GRANTED
        if (if (all) perms.all { granted(it) } else perms.any { granted(it) }) { cb(true); return }
        permCb = cb; permAll = all; permList = perms
        try { permLauncher.launch(perms.filter { !granted(it) }.toTypedArray()) } catch (e: Exception) { permCb = null; cb(false) }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // সিস্টেম নিজে অ্যাপ রিস্টার্ট করলে (ডার্ক মোড বদল ইত্যাদি) যে ট্যাবে ছিল সেখানেই ফেরা; নইলে সবসময় হোম পেজ
        if (b != null) getSharedPreferences("browser", MODE_PRIVATE).edit().putBoolean("reopen", true).commit()
        val frame = FrameLayout(this)
        browser = BrowserLayer(this)      // শুরুতেই হোম পেজ দেখায় (BrowserLayer এর init)
        frame.addView(browser, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        applyStatusBar()
        // ডাউনলোড নোটিফিকেশন দেখানোর জন্য (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            try { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (e: Exception) { }
        }
        // অন্য অ্যাপ থেকে লিংক খুললে (প্রথমবার চালুর সময়) হোমের উপরে নতুন ট্যাবে
        if (b == null) browser?.post { handleIntent(intent) }   // BrowserLayer এর নিজের startup এর পরে চলে
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (browser?.handleBack() == true) return
                finish()
            }
        })
    }

    // অন্য অ্যাপ থেকে লিংক/ফাইল/সার্চ খুললে এই ব্রাউজারে
    private fun handleIntent(i: Intent?) {
        i ?: return
        // ডাউনলোড নোটিফিকেশনে চাপলে সরাসরি Downloads তালিকা
        if (i.getBooleanExtra("open_downloads", false)) { i.removeExtra("open_downloads"); browser?.openDownloadsList(); return }
        val u = i.data
        if (i.action == Intent.ACTION_VIEW && u != null) browser?.open(u.toString())
        else if (i.action == Intent.ACTION_WEB_SEARCH) i.getStringExtra("query")?.let { q -> browser?.open("https://www.google.com/search?q=" + Uri.encode(q)) }
        else if (i.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT)?.let { t -> browser?.open(if (t.startsWith("http")) t else "https://www.google.com/search?q=" + Uri.encode(t)) }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    override fun onPause() { try { browser?.persist() } catch (e: Exception) { }; super.onPause() }

    override fun onDestroy() {
        try { browser?.release() } catch (e: Exception) { }
        try { browser?.destroyAll() } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onResume() { super.onResume(); applyStatusBar() }

    // স্ট্যাটাস বার ব্রাউজারের থিম (Dark/Light/System) অনুযায়ী
    private fun applyStatusBar() {
        try {
            val theme = getSharedPreferences("browser", MODE_PRIVATE).getString("theme", "dark")
            val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
            val light = theme == "light" || (theme == "system" && !night)
            val c = if (light) Color.parseColor("#DCE0F5") else Color.parseColor("#0B0F24")
            window.statusBarColor = c
            androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = light
        } catch (e: Exception) { }
    }
}
