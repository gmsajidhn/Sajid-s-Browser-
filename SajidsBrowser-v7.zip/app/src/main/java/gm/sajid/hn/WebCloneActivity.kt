package gm.sajid.hn

import android.Manifest
import android.app.ActivityManager
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** ইন-অ্যাপ ক্লোনের উইন্ডো: ইনস্টল ছাড়া, নিজের আলাদা লগইন/ডেটা নিয়ে চলে */
class WebCloneActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var bar: ProgressBar
    private var cloneId = ""
    private var startHost = ""
    private var gAskedAt = 0L
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private var pendingGeo: Pair<String, GeolocationPermissions.Callback>? = null
    private var acctCb: ((String?) -> Unit)? = null
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCb = null
    }
    private val acctPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = acctCb; acctCb = null
        cb?.invoke(if (r.resultCode == RESULT_OK) r.data?.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME) else null)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pendingPerm?.let { req ->
            val ok = req.resources.all { r -> needed(r).all { p -> granted(p) } }
            if (ok) req.grant(req.resources) else req.deny()
        }
        pendingPerm = null
        pendingGeo?.let { (o, cb) -> cb.invoke(o, granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION), false) }
        pendingGeo = null
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun needed(res: String): List<String> = when (res) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> listOf(Manifest.permission.CAMERA)
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> listOf(Manifest.permission.RECORD_AUDIO)
        else -> emptyList()
    }

    @Suppress("DEPRECATION")
    private fun pickGoogleAccount(cb: (String?) -> Unit) {
        acctCb = cb
        try { acctPicker.launch(android.accounts.AccountManager.newChooseAccountIntent(null, null, arrayOf("com.google"), false, null, null, null, null)) }
        catch (e: Exception) { acctCb = null; cb(null) }
    }

    private fun googleGate(url: String): Boolean {
        val u = try { Uri.parse(url) } catch (e: Exception) { return false }
        if (!GoogleLogin.shouldAsk(u)) return false
        val now = System.currentTimeMillis()
        if (now - gAskedAt < GoogleLogin.QUIET_MS) return false
        gAskedAt = now
        pickGoogleAccount { email -> web.loadUrl(if (email != null) GoogleLogin.withHint(url, email) else url) }
        return true
    }

    private fun root(x: String): String { val p = x.removePrefix("www.").split("."); return if (p.size >= 2) p.takeLast(2).joinToString(".") else x }
    private fun sameSite(h: String) = h.isNotEmpty() && root(h) == root(startHost)

    private fun loginLike(u: Uri): Boolean {
        val h = u.host ?: ""
        if (h == "accounts.google.com" || h == "appleid.apple.com" || h.endsWith("login.microsoftonline.com") || h.endsWith("facebook.com")) return true
        val p = (u.path ?: "").lowercase()
        return p.contains("oauth") || p.contains("login") || p.contains("signin") || p.contains("/auth")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cloneId = intent?.data?.host ?: ""
        val clone = WebCloneMgr.get(this, cloneId)
        if (clone == null) { Toast.makeText(this, "This clone was deleted", Toast.LENGTH_SHORT).show(); finish(); return }
        startHost = Uri.parse(clone.url).host ?: ""
        try { setTaskDescription(ActivityManager.TaskDescription(clone.name)) } catch (e: Throwable) { }
        window.statusBarColor = Color.parseColor("#0B0F24")

        web = WebView(this)
        if (!WebCloneMgr.applyProfile(web, cloneId))
            Toast.makeText(this, "This phone's WebView can't keep separate logins: clones may share logins", Toast.LENGTH_LONG).show()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = true
            useWideViewPort = true; loadWithOverviewMode = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = if (clone.desktop) desktopUa else userAgentString.replace("; wv", "").replace(Regex(" Version/\\d+\\.\\d+"), "")
        }
        val cm = WebCloneMgr.cookieMgr(cloneId)
        cm.setAcceptCookie(true)
        try { cm.setAcceptThirdPartyCookies(web, true) } catch (e: Exception) { }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val sch = u.scheme ?: ""
                if (sch == "http" || sch == "https") {
                    if (r.isForMainFrame && googleGate(u.toString())) return true
                    if (r.isForMainFrame && r.hasGesture() && !r.isRedirect && !sameSite(u.host ?: "") && !loginLike(u)) {
                        try { startActivity(Intent(this@WebCloneActivity, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                        return true
                    }
                    return false
                }
                try {
                    val i = if (sch == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); i.component = null; i.selector = null
                    startActivity(i)
                } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) { bar.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView, u: String?) { bar.visibility = View.GONE; try { WebCloneMgr.cookieMgr(cloneId).flush() } catch (e: Throwable) { } }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { bar.progress = p }
            override fun onShowFileChooser(x: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    val miss = req.resources.flatMap { needed(it) }.filter { !granted(it) }.distinct()
                    if (miss.isEmpty()) req.grant(req.resources)
                    else { pendingPerm = req; try { permLauncher.launch(miss.toTypedArray()) } catch (e: Exception) { pendingPerm = null; req.deny() } }
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                if (granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)) cb.invoke(origin, true, false)
                else { pendingGeo = origin to cb; try { permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) } catch (e: Exception) { pendingGeo = null; cb.invoke(origin, false, false) } }
            }
        }
        web.setDownloadListener { dl, ua, cd, mime, _ ->
            try {
                val rq = DownloadManager.Request(Uri.parse(dl))
                rq.setMimeType(mime)
                rq.addRequestHeader("Cookie", WebCloneMgr.cookieMgr(cloneId).getCookie(dl) ?: "")
                rq.addRequestHeader("User-Agent", ua)
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(dl, cd, mime))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't download this file here", Toast.LENGTH_SHORT).show()
            }
        }

        val rootView = FrameLayout(this)
        rootView.addView(web, FrameLayout.LayoutParams(-1, -1))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        rootView.addView(bar, FrameLayout.LayoutParams(-1, (3 * resources.displayMetrics.density).toInt()))
        setContentView(rootView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
        if (b == null) { if (!googleGate(clone.url)) web.loadUrl(clone.url) } else web.restoreState(b)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); try { web.saveState(o) } catch (e: Throwable) { } }
    override fun onPause() { try { WebCloneMgr.cookieMgr(cloneId).flush() } catch (e: Throwable) { }; super.onPause() }
    override fun onDestroy() { try { (web.parent as? ViewGroup)?.removeView(web); web.destroy() } catch (e: Throwable) { }; super.onDestroy() }
}
