package gm.sajid.hn

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec

// আসল অ্যাপ ক্লোন: ইনস্টল করা অ্যাপের APK কপি -> package/label বদল -> নতুন কী দিয়ে sign -> PackageInstaller দিয়ে ইনস্টল।
// ক্লোন একদম আলাদা অ্যাপ, তাই লগইন/ডেটা আলাদা। মূল ইঞ্জিন: ApkCloneCore.java
object ApkCloneMgr {
    const val ACTION_RESULT = "gm.sajid.hn.CLONE_INSTALL_RESULT"
    private const val PREFS = "browser"
    private const val KEY = "apkclones"
    private val ui = Handler(Looper.getMainLooper())

    class AppItem(val pkg: String, val label: String, val icon: Drawable?, val splits: Int)
    class ApkClone(val pkg: String, val orig: String, var name: String)

    // ---------- তালিকা ----------
    /** লঞ্চারে দেখা যায় এমন অ্যাপ (সিস্টেম ক্লোন/নিজের অ্যাপ বাদে) */
    fun listApps(c: Context): List<AppItem> {
        val pm = c.packageManager
        val clones = load(c).map { it.pkg }.toSet()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppItem>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            val p = ai.packageName
            if (p == c.packageName || p in clones || !seen.add(p)) continue
            out.add(AppItem(p, ri.loadLabel(pm).toString(), try { ri.loadIcon(pm) } catch (e: Throwable) { null }, ai.splitSourceDirs?.size ?: 0))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    // ---------- সংরক্ষিত ক্লোন ----------
    fun load(c: Context): MutableList<ApkClone> {
        val l = mutableListOf<ApkClone>()
        try {
            val a = JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); l.add(ApkClone(o.getString("p"), o.getString("o"), o.getString("n"))) }
        } catch (e: Exception) { }
        return l
    }

    private fun save(c: Context, l: List<ApkClone>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("p", it.pkg).put("o", it.orig).put("n", it.name)) }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun isInstalled(c: Context, pkg: String): Boolean = try { c.packageManager.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }

    /** ইনস্টল হয়ে থাকা ক্লোনের পরবর্তী নতুন package নাম (প্রতিটা ক্লোন আলাদা) */
    private fun nextPackage(c: Context, orig: String): String {
        val used = load(c).map { it.pkg }.toSet()
        var n = 1
        while (true) {
            val p = "gm.sajid.cl$n.$orig"
            if (p !in used && !isInstalled(c, p)) return p
            n++
        }
    }

    fun nextName(c: Context, label: String): String {
        val same = load(c).count { it.name == label || it.name.startsWith("$label ") }
        return if (same == 0) "$label 2" else "$label ${same + 2}"
    }

    // ---------- সাইনিং কী (অ্যাপের ভেতরে থাকা কী, সব ক্লোন একই কী-তে sign হয়, তাই আপডেট/রিনেম ডেটা না মুছে চলে) ----------
    private fun key(c: Context): Pair<PrivateKey, X509Certificate> {
        val kb = c.resources.openRawResource(R.raw.clone_key).use { it.readBytes() }
        val k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kb))
        val cert = c.resources.openRawResource(R.raw.clone_cert).use { CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate }
        return k to cert
    }

    fun canInstall(c: Context): Boolean = Build.VERSION.SDK_INT < 26 || c.packageManager.canRequestPackageInstalls()

    fun openInstallSettings(c: Context) {
        try { c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    // ---------- ক্লোন বানানো / আপডেট (একই package + একই কী = ডেটা না মুছে আপডেট) ----------
    /** ব্যাকগ্রাউন্ড থ্রেডে চলে; status() মেইন থ্রেডে বার্তা দেয়; শেষে onDone(সফলভাবে কমিট হলো কিনা) */
    fun clone(c: Context, orig: String, label: String, existingPkg: String?, status: (String) -> Unit, onDone: (Boolean) -> Unit) {
        Thread {
            fun st(m: String) = ui.post { status(m) }
            var ok = false
            try {
                val pm = c.packageManager
                val ai: ApplicationInfo = pm.getApplicationInfo(orig, 0)
                val newPkg = existingPkg ?: nextPackage(c, orig)
                val (k, cert) = key(c)
                val dir = File(c.cacheDir, "apkclone").apply { deleteRecursively(); mkdirs() }

                val srcs = ArrayList<File>()
                srcs.add(File(ai.sourceDir))
                ai.splitSourceDirs?.forEach { srcs.add(File(it)) }
                val outs = ArrayList<File>()
                for ((i, s) in srcs.withIndex()) {
                    st("Patching ${i + 1}/${srcs.size}: ${s.name}")
                    val o = ApkCloneCore.Options()
                    o.newPackage = newPkg
                    o.newLabel = if (i == 0) label else null      // label শুধু base APK তে
                    val m = ApkCloneCore.patchManifest(ApkCloneCore.readManifest(s), o)
                    val f = File(dir, if (i == 0) "base.apk" else "split_$i.apk")
                    st("Signing ${i + 1}/${srcs.size}")
                    ApkCloneCore.writeSignedApk(s, m, k, cert, f)
                    outs.add(f)
                }

                // রেজিস্ট্রিতে আগেই রাখি (ইনস্টল শেষ না হলেও তালিকায় দেখা যায়, না হলে ব্যর্থ হলে মুছে ফেলা হয়)
                val l = load(c)
                val ex = l.firstOrNull { it.pkg == newPkg }
                if (ex != null) ex.name = label else l.add(ApkClone(newPkg, orig, label))
                save(c, l)

                st("Installing… confirm on the system screen")
                install(c, newPkg, outs)
                ok = true
            } catch (e: Throwable) {
                ui.post { Toast.makeText(c, "Clone failed: " + (e.message ?: e.javaClass.simpleName), Toast.LENGTH_LONG).show() }
            }
            ui.post { onDone(ok) }
        }.start()
    }

    private fun install(c: Context, pkg: String, files: List<File>) {
        val pi = c.packageManager.packageInstaller
        val p = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        p.setAppPackageName(pkg)
        val id = pi.createSession(p)
        val s = pi.openSession(id)
        try {
            for (f in files) {
                s.openWrite(f.name, 0, f.length()).use { os ->
                    f.inputStream().use { it.copyTo(os, 1 shl 16) }
                    s.fsync(os)
                }
            }
            val i = Intent(c, CloneInstallReceiver::class.java).setAction(ACTION_RESULT).putExtra("pkg", pkg)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(c, id, i, flags).intentSender)
        } catch (e: Throwable) {
            try { s.abandon() } catch (x: Throwable) { }
            throw e
        } finally {
            try { s.close() } catch (x: Throwable) { }
        }
    }

    // ---------- খোলা / মোছা ----------
    fun launchIntent(c: Context, pkg: String): Intent? = c.packageManager.getLaunchIntentForPackage(pkg)

    fun open(c: Context, pkg: String): Boolean {
        val i = launchIntent(c, pkg) ?: return false
        return try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
    }

    /** সিস্টেমের আনইনস্টল স্ক্রিন; আনইনস্টলে ক্লোনের সব ডেটা মুছে যায় */
    fun uninstall(c: Context, pkg: String) {
        try { c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    /** তালিকা থেকে সরায় (আনইনস্টল হয়ে গেছে এমনগুলো) */
    fun forget(c: Context, pkg: String) { save(c, load(c).filter { it.pkg != pkg }) }

    fun cleanupGone(c: Context) { save(c, load(c).filter { isInstalled(c, it.pkg) }) }
}

/** সিস্টেমের ইনস্টল ফলাফল: নিশ্চিতকরণ স্ক্রিন খোলে, সফল/ব্যর্থ জানায় */
class CloneInstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        val st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        when (st) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java) else i.getParcelableExtra(Intent.EXTRA_INTENT)
                try { if (confirm != null) c.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Toast.makeText(c, "Couldn't open the install screen", Toast.LENGTH_LONG).show() }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                Toast.makeText(c, "Clone installed", Toast.LENGTH_SHORT).show()
                try { File(c.cacheDir, "apkclone").deleteRecursively() } catch (e: Exception) { }
            }
            else -> {
                val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "status $st"
                val pkg = i.getStringExtra("pkg")
                // ব্যবহারকারী বাতিল করলে বা ব্যর্থ হলে, অ্যাপ ইনস্টল না থাকলে তালিকা থেকেও সরাই
                if (pkg != null && !ApkCloneMgr.isInstalled(c, pkg)) ApkCloneMgr.forget(c, pkg)
                if (st != PackageInstaller.STATUS_FAILURE_ABORTED) Toast.makeText(c, "Install failed: $msg", Toast.LENGTH_LONG).show()
                try { File(c.cacheDir, "apkclone").deleteRecursively() } catch (e: Exception) { }
            }
        }
    }
}
