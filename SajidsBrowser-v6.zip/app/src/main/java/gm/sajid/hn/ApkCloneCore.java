package gm.sajid.hn;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.zip.*;

/**
 * APK ক্লোনের মূল ইঞ্জিন (শুধু JDK, কোনো Android API ছাড়া, তাই আলাদাভাবে টেস্ট করা যায়):
 *  1) binary AndroidManifest.xml এ package / label / authorities / permission বদলানো
 *  2) ZIP আবার সাজানো (resources.arsc ও native lib align সহ)
 *  3) APK Signature Scheme v2 দিয়ে নতুন কী-তে sign করা
 */
public final class ApkCloneCore {
    private ApkCloneCore() {}

    // ============================================================ AXML ============================================================
    private static final int RES_XML = 0x0003, STRING_POOL = 0x0001, XML_RESMAP = 0x0180;
    private static final int START_NS = 0x0100, END_NS = 0x0101, START_EL = 0x0102, END_EL = 0x0103, CDATA = 0x0104;
    private static final int T_REF = 0x01, T_STRING = 0x03;

    private static final Set<String> CLASS_ELEMENTS = new HashSet<>(Arrays.asList(
            "application", "activity", "activity-alias", "service", "receiver", "provider", "instrumentation"));
    private static final Set<String> CLASS_ATTRS = new HashSet<>(Arrays.asList(
            "name", "targetActivity", "backupAgent", "manageSpaceActivity", "parentActivityName", "appComponentFactory"));

    public static final class Options {
        public String newPackage;
        public String newLabel;            // null হলে label বদলাবে না
        public boolean renamePermissions = true;
    }

    /** একটা পার্স করা AXML: স্ট্রিং পুল + বাকি chunk গুলো কাঁচা বাইটে (শুধু attribute গুলো আমরা ছুঁই) */
    private static final class Pool {
        List<String> strings = new ArrayList<>();
        boolean utf8;
        int styleCount;
    }

    public static byte[] patchManifest(byte[] src, Options o) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN);
        if (b.getShort(0) != RES_XML) throw new IOException("Not a binary manifest");
        int fileSize = b.getInt(4);
        int pos = b.getShort(2) & 0xFFFF;

        // --- string pool ---
        if ((b.getShort(pos) & 0xFFFF) != STRING_POOL) throw new IOException("String pool missing");
        int poolStart = pos;
        int poolSize = b.getInt(pos + 4);
        Pool pool = readPool(b, poolStart);
        if (pool.styleCount != 0) throw new IOException("Manifest with styled strings is not supported");
        pos += poolSize;

        // --- বাকি chunk গুলো কপি করে রাখি, attribute সম্পাদনা করার জন্য একটা সংশোধনযোগ্য বাফার ---
        byte[] rest = Arrays.copyOfRange(src, pos, Math.min(src.length, fileSize));
        ByteBuffer r = ByteBuffer.wrap(rest).order(ByteOrder.LITTLE_ENDIAN);

        // প্রথম পাস: পুরোনো package নাম খুঁজি
        String oldPkg = null;
        int p = 0;
        while (p + 8 <= r.limit()) {
            int type = r.getShort(p) & 0xFFFF, size = r.getInt(p + 4);
            if (type == START_EL) {
                String el = str(pool, r.getInt(p + 20));
                if ("manifest".equals(el)) {
                    int ac = r.getShort(p + 28) & 0xFFFF;
                    for (int i = 0; i < ac; i++) {
                        int a = p + 36 + i * 20;
                        if ("package".equals(str(pool, r.getInt(a + 4)))) oldPkg = str(pool, r.getInt(a + 8));
                    }
                    break;
                }
            }
            if (size <= 0) throw new IOException("Corrupt manifest");
            p += size;
        }
        if (oldPkg == null) throw new IOException("package attribute not found");
        final String old = oldPkg;
        Map<String, Integer> added = new HashMap<>();

        // দ্বিতীয় পাস: attribute সম্পাদনা
        int actLabelAttr = -1;      // বর্তমান activity এর label attribute এর অফসেট (থাকলে)
        p = 0;
        while (p + 8 <= r.limit()) {
            int type = r.getShort(p) & 0xFFFF, size = r.getInt(p + 4);
            if (type == START_EL) {
                String el = str(pool, r.getInt(p + 20));
                if ("activity".equals(el) || "activity-alias".equals(el)) actLabelAttr = -1;
                int ac = r.getShort(p + 28) & 0xFFFF;
                for (int i = 0; i < ac; i++) {
                    int a = p + 36 + i * 20;
                    String an = str(pool, r.getInt(a + 4));
                    int dType = r.get(a + 15) & 0xFF;
                    int rawIdx = r.getInt(a + 8);
                    if (an == null) continue;

                    if ("manifest".equals(el) && "package".equals(an)) {
                        setString(r, a, add(pool, added, o.newPackage));
                    } else if ("manifest".equals(el) && ("sharedUserId".equals(an) || "sharedUserLabel".equals(an))) {
                        // sharedUserId থাকলে ক্লোন আসলটার সাথে জুড়ে যায়/ইনস্টল ফেল করে: অকেজো নামে বদলাই
                        if ("sharedUserId".equals(an) && dType == T_STRING) setString(r, a, add(pool, added, o.newPackage + ".uid"));
                    } else if (CLASS_ELEMENTS.contains(el) && CLASS_ATTRS.contains(an) && dType == T_STRING && rawIdx >= 0) {
                        // package বদলালে ".Foo" বা "Foo" এর অর্থ বদলে যায় — তাই পুরো নাম বসাই
                        String v = str(pool, rawIdx);
                        String full = fullClass(old, v);
                        if (full != null && !full.equals(v)) setString(r, a, add(pool, added, full));
                    } else if ("application".equals(el) && "label".equals(an) && o.newLabel != null) {
                        setString(r, a, add(pool, added, o.newLabel));
                    } else if (("activity".equals(el) || "activity-alias".equals(el)) && "label".equals(an)) {
                        actLabelAttr = a;      // পরে LAUNCHER category পেলে এটা বদলাব
                    } else if ("category".equals(el) && "name".equals(an) && dType == T_STRING && o.newLabel != null
                            && "android.intent.category.LAUNCHER".equals(str(pool, rawIdx)) && actLabelAttr >= 0) {
                        // লঞ্চার activity এর নিজস্ব label থাকলে হোম স্ক্রিনে সেটাই দেখায় — তাই সেটাও বদলাই
                        setString(r, actLabelAttr, add(pool, added, o.newLabel));
                    } else if ("provider".equals(el) && "authorities".equals(an) && dType == T_STRING) {
                        String v = str(pool, rawIdx);
                        if (v != null) setString(r, a, add(pool, added, renameAuthorities(v, old, o.newPackage)));
                    } else if (o.renamePermissions && ("permission".equals(el) || "permission-group".equals(el) || "permission-tree".equals(el)) && "name".equals(an) && dType == T_STRING) {
                        String v = str(pool, rawIdx);
                        if (v != null && v.startsWith(old + ".")) setString(r, a, add(pool, added, o.newPackage + v.substring(old.length())));
                    } else if (o.renamePermissions && "uses-permission".equals(el) && "name".equals(an) && dType == T_STRING) {
                        String v = str(pool, rawIdx);
                        if (v != null && v.startsWith(old + ".") && !v.startsWith("android.")) setString(r, a, add(pool, added, o.newPackage + v.substring(old.length())));
                    } else if ("application".equals(el) && "process".equals(an) && dType == T_STRING) {
                        String v = str(pool, rawIdx);
                        if (v != null && v.equals(old)) setString(r, a, add(pool, added, o.newPackage));
                        else if (v != null && v.startsWith(old + ":")) setString(r, a, add(pool, added, o.newPackage + v.substring(old.length())));
                    }
                }
            }
            if (type == END_EL) {
                String el1 = str(pool, r.getInt(p + 20));
                if ("activity".equals(el1) || "activity-alias".equals(el1)) actLabelAttr = -1;
            }
            if (size <= 0) throw new IOException("Corrupt manifest");
            p += size;
        }

        // স্ট্রিং পুল নতুন করে লিখি, তারপর header + পুল + বাকি chunk
        byte[] newPool = writePool(pool);
        int total = poolStart;            // XML header (সাধারণত 8 বাইট)
        ByteBuffer out = ByteBuffer.allocate(total + newPool.length + rest.length).order(ByteOrder.LITTLE_ENDIAN);
        out.put(src, 0, total);
        out.put(newPool);
        out.put(rest);
        out.putInt(4, out.capacity());
        return out.array();
    }

    private static String fullClass(String pkg, String v) {
        if (v == null || v.isEmpty()) return null;
        if (v.startsWith(".")) return pkg + v;
        if (v.indexOf('.') < 0) return pkg + "." + v;
        return v;
    }

    static String renameAuthorities(String v, String oldPkg, String newPkg) {
        String[] parts = v.split(";");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            String s = parts[i];
            if (s.equals(oldPkg)) s = newPkg;
            else if (s.startsWith(oldPkg + ".")) s = newPkg + s.substring(oldPkg.length());
            else s = newPkg + "." + s;     // অন্য কারো authority হলেও ক্লোনের নিজের নামে আলাদা করি, যাতে duplicate না হয়
            if (i > 0) sb.append(';');
            sb.append(s);
        }
        return sb.toString();
    }

    private static int add(Pool pool, Map<String, Integer> cache, String s) {
        Integer i = cache.get(s);
        if (i != null) return i;
        pool.strings.add(s);
        int idx = pool.strings.size() - 1;
        cache.put(s, idx);
        return idx;
    }

    /** attribute কে string টাইপে বদলে নতুন পুল-ইনডেক্স বসায় */
    private static void setString(ByteBuffer r, int a, int idx) {
        r.putInt(a + 8, idx);          // rawValue
        r.put(a + 15, (byte) T_STRING); // dataType
        r.putInt(a + 16, idx);         // data
    }

    private static String str(Pool p, int i) { return (i < 0 || i >= p.strings.size()) ? null : p.strings.get(i); }

    // ---------------- string pool পড়া/লেখা ----------------
    private static Pool readPool(ByteBuffer b, int s) throws IOException {
        Pool p = new Pool();
        int headerSize = b.getShort(s + 2) & 0xFFFF;
        int count = b.getInt(s + 8);
        p.styleCount = b.getInt(s + 12);
        int flags = b.getInt(s + 16);
        p.utf8 = (flags & 0x100) != 0;
        int strStart = b.getInt(s + 20);
        for (int i = 0; i < count; i++) {
            int off = b.getInt(s + headerSize + i * 4);
            int q = s + strStart + off;
            if (p.utf8) {
                int[] u = new int[1];
                q = readLen8(b, q, u);          // UTF-16 length (বাদ)
                int[] bl = new int[1];
                q = readLen8(b, q, bl);         // UTF-8 byte length
                byte[] d = new byte[bl[0]];
                for (int k = 0; k < d.length; k++) d[k] = b.get(q + k);
                p.strings.add(new String(d, StandardCharsets.UTF_8));
            } else {
                int n = b.getShort(q) & 0xFFFF; q += 2;
                if ((n & 0x8000) != 0) { n = ((n & 0x7FFF) << 16) | (b.getShort(q) & 0xFFFF); q += 2; }
                char[] c = new char[n];
                for (int k = 0; k < n; k++) c[k] = (char) (b.getShort(q + k * 2) & 0xFFFF);
                p.strings.add(new String(c));
            }
        }
        return p;
    }

    private static int readLen8(ByteBuffer b, int q, int[] out) {
        int v = b.get(q) & 0xFF; q++;
        if ((v & 0x80) != 0) { v = ((v & 0x7F) << 8) | (b.get(q) & 0xFF); q++; }
        out[0] = v;
        return q;
    }

    private static byte[] writePool(Pool p) throws IOException {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int n = p.strings.size();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = data.size();
            String s = p.strings.get(i);
            if (p.utf8) {
                byte[] u8 = s.getBytes(StandardCharsets.UTF_8);
                writeLen8(data, s.length());
                writeLen8(data, u8.length);
                data.write(u8);
                data.write(0);
            } else {
                int cl = s.length();
                if (cl > 0x7FFF) { data.write(((cl >> 16) & 0x7F) | 0x80); data.write((cl >> 24) & 0xFF); data.write(cl & 0xFF); data.write((cl >> 8) & 0xFF); }
                else { data.write(cl & 0xFF); data.write((cl >> 8) & 0xFF); }
                for (int k = 0; k < cl; k++) { char c = s.charAt(k); data.write(c & 0xFF); data.write((c >> 8) & 0xFF); }
                data.write(0); data.write(0);
            }
        }
        while (data.size() % 4 != 0) data.write(0);
        int headerSize = 28;
        int strStart = headerSize + n * 4;
        int size = strStart + data.size();
        ByteBuffer h = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        h.putShort((short) STRING_POOL); h.putShort((short) headerSize); h.putInt(size);
        h.putInt(n); h.putInt(0); h.putInt(p.utf8 ? 0x100 : 0); h.putInt(strStart); h.putInt(0);
        for (int i = 0; i < n; i++) h.putInt(offs[i]);
        h.put(data.toByteArray());
        return h.array();
    }

    private static void writeLen8(ByteArrayOutputStream o, int v) {
        if (v > 0x7F) { o.write(((v >> 8) & 0x7F) | 0x80); o.write(v & 0xFF); } else o.write(v);
    }

    // ============================================================ ZIP পুনর্লিখন (স্ট্রিমিং — বড় APK তেও মেমরি কম লাগে) ============================================================
    private static final class SrcEntry {
        String name; int method; long crc, csize, usize, lho;
    }

    public static byte[] readManifest(File apk) throws IOException {
        try (ZipFile zf = new ZipFile(apk)) {
            ZipEntry ze = zf.getEntry("AndroidManifest.xml");
            if (ze == null) throw new IOException("No AndroidManifest.xml in APK");
            try (InputStream in = zf.getInputStream(ze)) { return readAll(in); }
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream(Math.max(32, in.available()));
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        return o.toByteArray();
    }

    private static int u16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
    private static long u32(byte[] b, int o) { return (u16(b, o) | ((long) u16(b, o + 2) << 16)) & 0xFFFFFFFFL; }

    /** সোর্স ZIP এর central directory পড়ে */
    private static List<SrcEntry> readCentralDirectory(RandomAccessFile f) throws IOException {
        long len = f.length();
        int tail = (int) Math.min(len, 65557);
        byte[] t = new byte[tail];
        f.seek(len - tail); f.readFully(t);
        int e = -1;
        for (int i = tail - 22; i >= 0; i--) if (t[i] == 0x50 && t[i + 1] == 0x4b && t[i + 2] == 0x05 && t[i + 3] == 0x06) { e = i; break; }
        if (e < 0) throw new IOException("Not a ZIP/APK file");
        int count = u16(t, e + 10);
        long cdSize = u32(t, e + 12), cdOff = u32(t, e + 16);
        if (count == 0xFFFF || cdOff == 0xFFFFFFFFL) throw new IOException("ZIP64 APK is not supported");
        byte[] cd = new byte[(int) cdSize];
        f.seek(cdOff); f.readFully(cd);
        List<SrcEntry> list = new ArrayList<>();
        int p = 0;
        for (int i = 0; i < count; i++) {
            if (u32(cd, p) != 0x02014b50L) throw new IOException("Corrupt central directory");
            SrcEntry s = new SrcEntry();
            s.method = u16(cd, p + 10); s.crc = u32(cd, p + 16); s.csize = u32(cd, p + 20); s.usize = u32(cd, p + 24);
            int nl = u16(cd, p + 28), el = u16(cd, p + 30), cl = u16(cd, p + 32);
            s.lho = u32(cd, p + 42);
            s.name = new String(cd, p + 46, nl, StandardCharsets.UTF_8);
            list.add(s);
            p += 46 + nl + el + cl;
        }
        return list;
    }

    private static final class OutEntry { String name; int method; long crc, csize, usize, offset; int dosTime, dosDate; }

    private static void w16(OutputStream o, int v) throws IOException { o.write(v & 0xFF); o.write((v >> 8) & 0xFF); }
    private static void w32(OutputStream o, long v) throws IOException { w16(o, (int) (v & 0xFFFF)); w16(o, (int) ((v >> 16) & 0xFFFF)); }

    /**
     * src APK থেকে সব এন্ট্রি (পুরোনো সাইনেচার বাদে) যেমন আছে তেমন কপি করে, AndroidManifest.xml এর জায়গায় newManifest বসিয়ে,
     * ফাইলটা v2 সাইনেচার দিয়ে out এ লেখে। কোনো এন্ট্রি আনকমপ্রেস/রিকমপ্রেস করা হয় না, তাই দ্রুত আর মেমরি কম।
     */
    public static void writeSignedApk(File src, byte[] newManifest, PrivateKey key, X509Certificate cert, File out) throws Exception {
        List<OutEntry> outs = new ArrayList<>();
        long part1Len;
        try (RandomAccessFile in = new RandomAccessFile(src, "r");
             CountingOut os = new CountingOut(new BufferedOutputStream(new FileOutputStream(out), 1 << 16))) {
            List<SrcEntry> ents = readCentralDirectory(in);
            byte[] buf = new byte[1 << 16];
            boolean sawManifest = false;
            for (SrcEntry se : ents) {
                String n = se.name;
                if (n.endsWith("/")) continue;
                String up = n.toUpperCase(Locale.ROOT);
                if (up.startsWith("META-INF/") && (up.endsWith(".SF") || up.endsWith(".RSA") || up.endsWith(".DSA") || up.endsWith(".EC") || up.equals("META-INF/MANIFEST.MF"))) continue;

                OutEntry oe = new OutEntry();
                oe.name = n; oe.dosTime = 0; oe.dosDate = (1 << 5) | 1 | ((2020 - 1980) << 9);   // নির্দিষ্ট তারিখ: ফলাফল সবসময় একই
                byte[] mem = null;
                if (n.equals("AndroidManifest.xml")) {
                    sawManifest = true;
                    mem = newManifest; oe.method = 0; oe.usize = mem.length;
                    CRC32 c = new CRC32(); c.update(mem); oe.crc = c.getValue(); oe.csize = mem.length;
                    // manifest ছোট; stored রাখলেও চলে, তবে অনেক টুল compressed আশা করে না — stored নিরাপদ ও সহজ
                } else {
                    oe.method = se.method; oe.crc = se.crc; oe.csize = se.csize; oe.usize = se.usize;
                }
                oe.offset = os.count;
                byte[] nm = n.getBytes(StandardCharsets.UTF_8);
                int extra = 0;
                if (oe.method == 0) {
                    int align = n.endsWith(".so") ? 4096 : 4;
                    long dataStart = oe.offset + 30 + nm.length;
                    extra = (int) ((align - (dataStart % align)) % align);
                }
                w32(os, 0x04034b50L); w16(os, 20); w16(os, 0x0800); w16(os, oe.method);
                w16(os, oe.dosTime); w16(os, oe.dosDate);
                w32(os, oe.crc); w32(os, oe.csize); w32(os, oe.usize);
                w16(os, nm.length); w16(os, extra);
                os.write(nm); if (extra > 0) os.write(new byte[extra]);
                if (mem != null) os.write(mem);
                else {
                    // সোর্সের local header এর পরের কাঁচা ডেটা কপি
                    byte[] lh = new byte[30];
                    in.seek(se.lho); in.readFully(lh);
                    if (u32(lh, 0) != 0x04034b50L) throw new IOException("Corrupt local header for " + n);
                    long dataOff = se.lho + 30 + u16(lh, 26) + u16(lh, 28);
                    in.seek(dataOff);
                    long left = se.csize;
                    while (left > 0) {
                        int r = in.read(buf, 0, (int) Math.min(buf.length, left));
                        if (r < 0) throw new IOException("Unexpected end of APK");
                        os.write(buf, 0, r); left -= r;
                    }
                }
                outs.add(oe);
            }
            if (!sawManifest) throw new IOException("No AndroidManifest.xml in APK");
            os.flush();
            part1Len = os.count;
        }

        // central directory + EOCD
        ByteArrayOutputStream cdb = new ByteArrayOutputStream();
        for (OutEntry z : outs) {
            byte[] nm = z.name.getBytes(StandardCharsets.UTF_8);
            w32(cdb, 0x02014b50L); w16(cdb, 20); w16(cdb, 20); w16(cdb, 0x0800); w16(cdb, z.method);
            w16(cdb, z.dosTime); w16(cdb, z.dosDate);
            w32(cdb, z.crc); w32(cdb, z.csize); w32(cdb, z.usize);
            w16(cdb, nm.length); w16(cdb, 0); w16(cdb, 0);
            w16(cdb, 0); w16(cdb, 0); w32(cdb, 0); w32(cdb, z.offset);
            cdb.write(nm);
        }
        byte[] part3 = cdb.toByteArray();
        ByteArrayOutputStream eb = new ByteArrayOutputStream();
        w32(eb, 0x06054b50L); w16(eb, 0); w16(eb, 0); w16(eb, outs.size()); w16(eb, outs.size());
        w32(eb, part3.length); w32(eb, part1Len); w16(eb, 0);
        byte[] part4 = eb.toByteArray();

        byte[] digest = contentDigest(out, part1Len, part3, part4);
        byte[] block = buildSigningBlock(digest, key, cert);
        ByteBuffer.wrap(part4).order(ByteOrder.LITTLE_ENDIAN).putInt(16, (int) (part1Len + block.length));
        try (OutputStream fo = new BufferedOutputStream(new FileOutputStream(out, true), 1 << 16)) {
            fo.write(block); fo.write(part3); fo.write(part4);
        }
    }

    private static final class CountingOut extends FilterOutputStream {
        long count;
        CountingOut(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); count++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); count += len; }
    }

    // ============================================================ APK Signature Scheme v2 ============================================================
    private static final int CHUNK = 1024 * 1024;
    private static final int SIG_RSA_PKCS1_SHA256 = 0x0103;
    private static final int V2_ID = 0x7109871a;

    private static byte[] buildSigningBlock(byte[] digest, PrivateKey key, X509Certificate cert) throws Exception {

        ByteArrayOutputStream digests = new ByteArrayOutputStream();
        digests.write(le32(4 + 4 + digest.length)); digests.write(le32(SIG_RSA_PKCS1_SHA256)); digests.write(le32(digest.length)); digests.write(digest);
        byte[] digestsSeq = digests.toByteArray();

        byte[] certBytes = cert.getEncoded();
        byte[] certsSeq = concat(le32(certBytes.length), certBytes);

        ByteArrayOutputStream sd = new ByteArrayOutputStream();
        sd.write(le32(digestsSeq.length)); sd.write(digestsSeq);
        sd.write(le32(certsSeq.length)); sd.write(certsSeq);
        sd.write(le32(0));      // additional attributes
        byte[] signedData = sd.toByteArray();

        Signature sg = Signature.getInstance("SHA256withRSA");
        sg.initSign(key); sg.update(signedData);
        byte[] sig = sg.sign();

        ByteArrayOutputStream sigs = new ByteArrayOutputStream();
        sigs.write(le32(4 + 4 + sig.length)); sigs.write(le32(SIG_RSA_PKCS1_SHA256)); sigs.write(le32(sig.length)); sigs.write(sig);
        byte[] sigsSeq = sigs.toByteArray();

        byte[] pub = cert.getPublicKey().getEncoded();

        ByteArrayOutputStream signer = new ByteArrayOutputStream();
        signer.write(le32(signedData.length)); signer.write(signedData);
        signer.write(le32(sigsSeq.length)); signer.write(sigsSeq);
        signer.write(le32(pub.length)); signer.write(pub);
        byte[] signerBytes = signer.toByteArray();

        byte[] signers = concat(le32(signerBytes.length), signerBytes);
        byte[] value = concat(le32(signers.length), signers);

        // pair: uint64 length, uint32 id, value
        long pairLen = 4 + value.length;
        ByteArrayOutputStream pair = new ByteArrayOutputStream();
        pair.write(le64(pairLen)); pair.write(le32(V2_ID)); pair.write(value);
        byte[] pairBytes = pair.toByteArray();

        long blockSize = pairBytes.length + 8 + 16;      // pairs + size(8) + magic(16)
        ByteArrayOutputStream blk = new ByteArrayOutputStream();
        blk.write(le64(blockSize)); blk.write(pairBytes); blk.write(le64(blockSize));
        blk.write("APK Sig Block 42".getBytes(StandardCharsets.US_ASCII));
        return blk.toByteArray();
    }

    /** v2 digest: ফাইলের প্রথম part1Len বাইট (ডিস্ক থেকে ১MB করে পড়ে) + central directory + EOCD */
    private static byte[] contentDigest(File f, long part1Len, byte[] p3, byte[] p4) throws Exception {
        List<byte[]> chunks = new ArrayList<>();
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[CHUNK];
            long left = part1Len;
            while (left > 0) {
                int want = (int) Math.min(CHUNK, left), got = 0;
                while (got < want) { int r = in.read(buf, got, want - got); if (r < 0) throw new IOException("Short read"); got += r; }
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update((byte) 0xa5); md.update(le32(want)); md.update(buf, 0, want);
                chunks.add(md.digest());
                left -= want;
            }
        }
        for (byte[] part : new byte[][]{p3, p4}) {
            for (int off = 0; off < part.length; off += CHUNK) {
                int len = Math.min(CHUNK, part.length - off);
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update((byte) 0xa5); md.update(le32(len)); md.update(part, off, len);
                chunks.add(md.digest());
            }
        }
        MessageDigest top = MessageDigest.getInstance("SHA-256");
        top.update((byte) 0x5a); top.update(le32(chunks.size()));
        for (byte[] c : chunks) top.update(c);
        return top.digest();
    }

    private static byte[] le32(int v) { return new byte[]{(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24)}; }
    private static byte[] le64(long v) { byte[] b = new byte[8]; for (int i = 0; i < 8; i++) b[i] = (byte) (v >> (8 * i)); return b; }
    private static byte[] concat(byte[] a, byte[] b) { byte[] r = Arrays.copyOf(a, a.length + b.length); System.arraycopy(b, 0, r, a.length, b.length); return r; }
}
