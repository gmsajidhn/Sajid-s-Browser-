package com.sajid.browser

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// Sajid Browser: standalone host for BrowserLayer (the browser was split out of Sajid's Study Tracker).
class MainActivity : AppCompatActivity() {
    lateinit var browser: BrowserLayer

    // ---------- image pick (profile photo / shortcut icon) ----------
    private var imageCb: ((Uri?) -> Unit)? = null
    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = imageCb; imageCb = null; cb?.invoke(uri)
    }
    fun pickImage(cb: (Uri?) -> Unit) {
        imageCb = cb
        try { imagePicker.launch("image/*") } catch (e: Exception) { imageCb = null; cb(null) }
    }

    // ---------- Lens: take a photo ----------
    private var camCb: ((Uri?) -> Unit)? = null
    private var camUri: Uri? = null
    private val camLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val cb = camCb; camCb = null; cb?.invoke(if (ok) camUri else null)
    }
    fun takePhoto(cb: (Uri?) -> Unit) {
        requestPerms(arrayOf(Manifest.permission.CAMERA), true) { granted ->
            if (!granted) { Toast.makeText(this, "Camera permission is needed to take a photo", Toast.LENGTH_SHORT).show(); cb(null); return@requestPerms }
            try {
                val dir = java.io.File(cacheDir, "lens").apply { mkdirs() }
                val f = java.io.File.createTempFile("shot", ".jpg", dir)
                val u = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                camUri = u; camCb = cb; camLauncher.launch(u)
            } catch (e: Exception) { camCb = null; cb(null) }
        }
    }

    // ---------- extension file pick ----------
    private var docCb: ((Uri?, String) -> Unit)? = null
    private val docPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val cb = docCb; docCb = null
        var n = ""
        if (uri != null) try { contentResolver.query(uri, null, null, null, null)?.use { c -> val ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && ix >= 0) n = c.getString(ix) ?: "" } } catch (e: Exception) { }
        cb?.invoke(uri, n)
    }
    fun pickDoc(cb: (Uri?, String) -> Unit) { docCb = cb; try { docPicker.launch(arrayOf("*/*")) } catch (e: Exception) { docCb = null; cb(null, "") } }

    // ---------- phone lock check before showing saved passwords ----------
    private var lockCb: ((Boolean) -> Unit)? = null
    private val lockLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = lockCb; lockCb = null; cb?.invoke(r.resultCode == android.app.Activity.RESULT_OK)
    }
    fun confirmDeviceLock(title: String, cb: (Boolean) -> Unit) {
        try {
            val km = getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (!km.isDeviceSecure) { cb(true); return }
            val i = km.createConfirmDeviceCredentialIntent(title, null)
            if (i == null) { cb(true); return }
            lockCb = cb; lockLauncher.launch(i)
        } catch (e: Exception) { lockCb = null; cb(false) }
    }

    // ---------- website file upload ----------
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    fun pickFile(cb: ValueCallback<Array<Uri>>, intent: Intent): Boolean {
        fileCb?.onReceiveValue(null); fileCb = cb
        return try { chooser.launch(intent); true } catch (e: Exception) { fileCb = null; false }
    }

    // ---------- site permissions (location / camera / mic) ----------
    private var permCb: ((Boolean) -> Unit)? = null
    private var permAll = true
    private var permList: Array<String> = emptyArray()
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val cb = permCb; permCb = null
        val ok = if (permAll) permList.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
                 else permList.any { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        cb?.invoke(ok)
    }
    fun requestPerms(perms: Array<String>, all: Boolean, cb: (Boolean) -> Unit) {
        fun granted(x: String) = ContextCompat.checkSelfPermission(this, x) == PackageManager.PERMISSION_GRANTED
        if (if (all) perms.all { granted(it) } else perms.any { granted(it) }) { cb(true); return }
        permCb = cb; permAll = all; permList = perms
        try { permLauncher.launch(perms.filter { !granted(it) }.toTypedArray()) } catch (e: Exception) { permCb = null; cb(false) }
    }

    // ---------- download notifications (Android 13+), asked once ----------
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private fun askNotifOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        val sp = getSharedPreferences("perm", MODE_PRIVATE)
        if (sp.getBoolean("notifAsked", false)) return
        sp.edit().putBoolean("notifAsked", true).apply()
        try { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (e: Exception) { }
    }

    // ---------- links / files / shared text from other apps ----------
    private fun urlFrom(i: Intent?): String? {
        i ?: return null
        val u = i.data
        return when {
            i.action == Intent.ACTION_VIEW && u != null -> u.toString()
            i.action == Intent.ACTION_WEB_SEARCH -> i.getStringExtra("query")?.let { "https://www.google.com/search?q=" + Uri.encode(it) }
            i.action == Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { t -> if (t.startsWith("http")) t else "https://www.google.com/search?q=" + Uri.encode(t) }
            else -> null
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        urlFrom(intent)?.let { u -> browser.post { browser.open(u) } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        browser = BrowserLayer(this)
        val frame = FrameLayout(this)
        frame.addView(browser, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        val url = if (b == null) urlFrom(intent) else null
        browser.post {
            if (browser.hasTabs()) { browser.show(); if (url != null) browser.open(url) }
            else if (url != null) browser.open(url)
            else browser.openHome()
        }
        askNotifOnce()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!browser.handleBack()) { browser.exiting = true; finish() }
            }
        })
    }

    override fun onPause() { try { browser.persist() } catch (e: Exception) { }; super.onPause() }

    override fun onDestroy() {
        try { browser.release() } catch (e: Exception) { }
        try { browser.destroyAll() } catch (e: Exception) { }
        super.onDestroy()
    }
}
