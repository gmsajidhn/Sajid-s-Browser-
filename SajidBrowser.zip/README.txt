Sajid Browser - standalone Android browser (split out of Sajid's Study Tracker)

GitHub এ আপলোড:
1) নতুন Private repo বানাও (keystore আছে, তাই Private রাখা ভালো)।
2) zip এক্সট্র্যাক্ট করে ভেতরের সব ফাইল/ফোল্ডার আপলোড করো (.github ফোল্ডারসহ)।
   .github না গেলে: Add file -> Create new file -> নামের ঘরে  .github/workflows/build.yml  লিখে build.yml এর লেখা পেস্ট করো।
3) Actions ট্যাব -> Build APK -> Run workflow (বা commit করলেই নিজে চলবে)।
4) বিল্ড শেষে Artifacts থেকে SajidBrowser-APK ডাউনলোড করে ইনস্টল।

Package: com.sajid.browser  (Study Tracker থেকে সম্পূর্ণ আলাদা অ্যাপ)
