Sajid's Browser - আলাদা ব্রাউজার অ্যাপ (Study Tracker থেকে আলাদা করা)
GitHub এ নতুন একটা রিপোজিটরিতে এই সব ফাইল (.github ফোল্ডারসহ) আপলোড করো -> Actions ট্যাব -> Build APK -> Artifacts থেকে SajidsBrowser-APK ডাউনলোড।

- অ্যাপ আইডি: gm.sajid.browser (Study Tracker এর gm.sajid.hn থেকে আলাদা, দুটো একসাথে ইনস্টল থাকবে)
- অ্যাপ আইকন = দেওয়া ছবিটাই, কোনো কাটাকাটি ছাড়া (পুরো ছবি)
- অ্যাপে ঢুকলেই হোম পেজ (সার্চ + শর্টকাট) দেখায়
- Back চাপলে হোম পেজ থেকে অ্যাপ বন্ধ হয়; শেষ ট্যাব বন্ধ করলে আবার হোম পেজ আসে
- সব আগের ব্রাউজার ফিচার একই: ট্যাব, ইনকগনিটো, প্রোফাইল, বুকমার্ক, হিস্টোরি, পাসওয়ার্ড, ডাউনলোড, PDF, Lens, এক্সটেনশন, থিম
- একই sajid.keystore দিয়ে সাইন হয়, তাই পরে আপডেট করলে আনইনস্টল লাগবে না

===== v1.1 নতুন =====
ডাউনলোড (Chrome-এর মতো):
- মেনু -> Downloads: অ্যাপের ভেতরেই ডাউনলোড তালিকা (চলমান ডাউনলোডের প্রগ্রেস বার, Open / Share / Copy link / Retry / Cancel / Delete)
- সব ধরনের ডাউনলোড তালিকায় আসে (লিংক, blob, data, ছবি, প্রিন্ট-PDF)
- APK/EXE ইত্যাদি ক্ষতিকর হতে পারে এমন ফাইলের আগে সাবধান-বার্তা
- নেট চলে গেলে সিস্টেম ডাউনলোড ম্যানেজার নিজেই আবার চালু করে (Resume)
বিজ্ঞাপন / জুয়া ব্লক (Brave-এর মতো):
- অনেক বেশি অ্যাড/ট্র্যাকার নেটওয়ার্ক ব্লক + পেজের বিজ্ঞাপন লুকানো
- YouTube: ভিডিও অ্যাড কাটা/স্কিপ, ফিডের অ্যাড, ব্যানার লুকানো (YouTube প্রায়ই বদলায়, তাই মাঝে মাঝে আপডেট লাগতে পারে)
- জুয়া/বেটিং/ক্যাসিনো সাইটের বিজ্ঞাপন, পপআপ, অটো-রিডাইরেক্ট ব্লক (Settings -> Site settings -> Gambling sites & ads দিয়ে বন্ধ করা যায়)
- ইউজার ক্লিক ছাড়া পপআপ ডিফল্টে ব্লক

===== v1.2 =====
- শর্টকাট এডিটে এখন রঙও বদলানো যায় (ছবির মতোই): Edit shortcut -> রঙের গোল বাটন -> Save. "Default icon & colour" চাপলে আগের অবস্থা
- YouTube অ্যাড ব্লক আরও শক্ত (fetch/text/XHR রেসপন্স থেকেও অ্যাড তথ্য বাদ, অ্যাড ধরার উপায় বাড়ানো)

===== v1.3 App Cloner =====
- মেনুর একদম নিচে "App Cloner": WhatsApp Web, Facebook, Instagram, Telegram, Gmail, YouTube বা কাস্টম ওয়েব লিংকের আলাদা browser profile তৈরি করা যায়। এটি ইনস্টল করা Android APK/native app clone করে না।
- প্রতিটি clone আলাদা WebView profile ব্যবহার করে যখন ফোনের Android System WebView/Chrome provider MULTI_PROFILE সমর্থন করে। সমর্থন না থাকলে অ্যাপ সতর্কবার্তা দেখায়; সে ক্ষেত্রে cookies/login data অন্য profile-এর সঙ্গে shared হতে পারে।
- Multi-profile সমর্থিত হলে Delete clone তার WebView profile, cookies, history, bookmarks ও icon মুছে দেয়। সমর্থন না থাকলে shared cookies নিরাপদে আলাদা করে মোছা সম্ভব নয়; অ্যাপ সেটি স্পষ্টভাবে জানায়।
- "Add to home screen" দিয়ে shortcut; Edit দিয়ে নাম/রঙ/ছবি বদলালে shortcut update করার চেষ্টা করে।
- "Choose phone Google account": Android account chooser থেকে একটি ইমেইল বেছে Google sign-in page-এ email prefill করে। এটি Google password/token বা অন্য অ্যাপের account data-তে access দেয় না।
- Web app clone-এর সংখ্যা নির্দিষ্ট করে বাঁধা নয়; বাস্তবে ফোনের storage, memory এবং website/provider সীমাবদ্ধতা প্রযোজ্য।
