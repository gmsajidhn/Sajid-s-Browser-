package gm.sajid.hn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// ডাউনলোডের তালিকা (Chrome-এর Downloads পেজের মতো): নাম, লিংক, টাইপ, সময়, ফাইলের uri / DownloadManager id
class DlRec(val key: String, val name: String, val url: String, val mime: String, val time: Long, val uri: String, val dmId: Long)

object DlStore {
    private const val K = "dlList"
    private const val MAX = 200
    private fun sp(c: Context) = c.getSharedPreferences("browser", Context.MODE_PRIVATE)

    @Synchronized fun all(c: Context): MutableList<DlRec> {
        val out = ArrayList<DlRec>()
        try {
            val a = JSONArray(sp(c).getString(K, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(DlRec(o.getString("k"), o.optString("n"), o.optString("u"), o.optString("m"), o.optLong("t"), o.optString("f"), o.optLong("d", -1L)))
            }
        } catch (e: Exception) { }
        return out
    }

    @Synchronized private fun save(c: Context, l: List<DlRec>) {
        val a = JSONArray()
        l.take(MAX).forEach { r ->
            a.put(JSONObject().put("k", r.key).put("n", r.name).put("u", r.url).put("m", r.mime).put("t", r.time).put("f", r.uri).put("d", r.dmId))
        }
        sp(c).edit().putString(K, a.toString()).apply()
    }

    @Synchronized fun add(c: Context, r: DlRec) {
        val l = all(c); l.removeAll { it.key == r.key }; l.add(0, r); save(c, l)
    }

    @Synchronized fun remove(c: Context, key: String) {
        val l = all(c); l.removeAll { it.key == key }; save(c, l)
    }

    @Synchronized fun clear(c: Context) { save(c, emptyList()) }
}
