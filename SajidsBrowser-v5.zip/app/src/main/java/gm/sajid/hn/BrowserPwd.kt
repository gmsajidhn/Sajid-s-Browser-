package gm.sajid.hn

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

// ===== সেভ করা পাসওয়ার্ড (Android Keystore দিয়ে এনক্রিপ্ট করা) =====
class PwdStore(c: Context) {
    class Cred(val host: String, val user: String, val pass: String)
    private val sp = c.getSharedPreferences("browser", Context.MODE_PRIVATE)
    private fun k(p: String) = "pwds_$p"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("bpwd", null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder("bpwd", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    private fun enc(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }
    private fun dec(s: String): String = try {
        val (iv, ct) = s.split(":")
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
        String(c.doFinal(Base64.decode(ct, Base64.NO_WRAP)))
    } catch (e: Throwable) { "" }

    fun list(p: String): MutableList<Cred> {
        val out = mutableListOf<Cred>()
        try {
            val a = JSONArray(sp.getString(k(p), "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Cred(o.getString("h"), o.getString("u"), dec(o.getString("p")))) }
        } catch (e: Exception) { }
        return out
    }
    private fun write(p: String, l: List<Cred>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("h", it.host).put("u", it.user).put("p", enc(it.pass))) }
        sp.edit().putString(k(p), a.toString()).apply()
    }
    fun find(p: String, host: String) = list(p).firstOrNull { it.host == host }
    fun has(p: String, host: String, u: String, pw: String) = list(p).any { it.host == host && it.user == u && it.pass == pw }
    fun put(p: String, host: String, u: String, pw: String) {
        val l = list(p); l.removeAll { it.host == host && it.user == u }; l.add(0, Cred(host, u, pw)); write(p, l)
    }
    fun remove(p: String, host: String, u: String) { val l = list(p); l.removeAll { it.host == host && it.user == u }; write(p, l) }
    fun clearAll(p: String) { sp.edit().remove(k(p)).apply() }
    fun never(host: String) = sp.getStringSet("pwd_never", emptySet())!!.contains(host)
    fun setNever(host: String) { sp.edit().putStringSet("pwd_never", HashSet(sp.getStringSet("pwd_never", emptySet())!!).apply { add(host) }).apply() }

    // গুগল পাসওয়ার্ড ম্যানেজার / ক্রোম থেকে এক্সপোর্ট করা CSV (name,url,username,password)
    fun importCsv(p: String, text: String): Int {
        val rows = text.lines().filter { it.isNotBlank() }
        if (rows.isEmpty()) return 0
        fun split(line: String): List<String> {
            val r = mutableListOf<String>(); val sb = StringBuilder(); var q = false; var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (ch == '"') { if (q && i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ } else q = !q }
                else if (ch == ',' && !q) { r.add(sb.toString()); sb.clear() } else sb.append(ch)
                i++
            }
            r.add(sb.toString()); return r
        }
        val head = split(rows[0]).map { it.lowercase().trim() }
        val iu = head.indexOf("url"); val iun = head.indexOf("username"); val ip = head.indexOf("password"); val inm = head.indexOf("name")
        if (iun < 0 || ip < 0) return 0
        var n = 0
        for (r in rows.drop(1)) {
            val f = split(r)
            val raw = (if (iu >= 0) f.getOrNull(iu) else null).orEmpty().ifBlank { f.getOrNull(inm).orEmpty() }
            val host = (android.net.Uri.parse(if (raw.contains("://")) raw else "https://$raw").host ?: continue).removePrefix("www.")
            val u = f.getOrNull(iun).orEmpty(); val pw = f.getOrNull(ip).orEmpty()
            if (pw.isEmpty()) continue
            put(p, host, u, pw); n++
        }
        return n
    }
}

// ===== বিজ্ঞাপন + জুয়া ব্লক (Brave-এর মতো: নেটওয়ার্ক ব্লক + পেজ ক্লিন + YouTube অ্যাড কাটা) =====
object AdBlock {
    // বিজ্ঞাপন / ট্র্যাকার নেটওয়ার্ক (সাবডোমেইনসহ ব্লক হয়)
    private val hosts = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "pagead2.googlesyndication.com",
        "googletagservices.com", "googletagmanager.com.ads", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com", "advertising.com", "adform.net",
        "amazon-adsystem.com", "scorecardresearch.com", "quantserve.com", "moatads.com", "adcolony.com", "applovin.com", "unityads.unity3d.com",
        "ads.mopub.com", "inmobi.com", "popads.net", "popcash.net", "propellerads.com", "exoclick.com", "juicyads.com", "trafficjunky.net",
        "adsterra.com", "mgid.com", "revcontent.com", "smartadserver.com", "yieldmo.com", "teads.tv", "media.net", "ad.gt", "adskeeper.com",
        "hotjar.com", "mc.yandex.ru", "an.yandex.ru", "ads.yahoo.com", "analytics.yahoo.com", "ads.twitter.com",
        "static.ads-twitter.com", "ads.linkedin.com", "bat.bing.com", "serving-sys.com", "2mdn.net", "adition.com", "zedo.com", "onetag-sys.com",
        // আরও বিজ্ঞাপন নেটওয়ার্ক / পপআন্ডার / রিডাইরেক্ট অ্যাড
        "googleads.g.doubleclick.net", "static.doubleclick.net", "s0.2mdn.net", "adsafeprotected.com", "doubleverify.com", "iasds01.com",
        "bidswitch.net", "sharethrough.com", "triplelift.com", "33across.com", "indexww.com", "contextweb.com", "lijit.com", "sovrn.com",
        "gumgum.com", "spotxchange.com", "springserve.com", "adroll.com", "bluekai.com", "demdex.net", "krxd.net", "everesttech.net",
        "mathtag.com", "turn.com", "tapad.com", "liadm.com", "id5-sync.com", "pubmine.com", "ezoic.net", "monetag.com", "clickadu.com",
        "hilltopads.net", "richpush.co", "pushwoosh.com", "adcash.com", "bidvertiser.com", "revenuehits.com", "evadav.com",
        "ero-advertising.com", "tsyndicate.com", "a-ads.com", "coinzilla.com", "bitmedia.io", "cointraffic.io", "adbooth.net",
        "yllix.com", "admaven.com", "adspyglass.com", "directrev.com", "dolohen.com", "acceptable.a-ads.com", "clickaine.com",
        "onclickads.net", "onclkds.com", "adxpansion.com", "pushame.com", "notix.io", "pushnami.com", "vidazoo.com", "vi-serve.com",
        "ad-maven.com", "ads.pubmatic.com", "adtng.com", "realsrv.com", "tubecorporate.com", "syndication.exoclick.com",
        "mc.yandex.com", "adfox.ru", "yandexadexchange.net", "ads.vk.com", "ad.mail.ru", "top-fwz1.mail.ru", "smaato.net", "admob.com",
        "chartboost.com", "vungle.com", "ironsrc.com", "supersonicads.com", "startappservice.com", "tapjoy.com", "fyber.com", "mintegral.com",
        "pangleglobal.com", "byteoversea.com", "ads.tiktok.com", "analytics.tiktok.com", "branch.io.ads", "adjust.com.ads",
        "securepubads.g.doubleclick.net", "tpc.googlesyndication.com", "partner.googleadservices.com", "ade.googlesyndication.com"
    )

    // জুয়া / বেটিং / ক্যাসিনো সাইট — এদের বিজ্ঞাপন, পপআপ, রিডাইরেক্ট আর ক্লিক-করা লিংক আটকানো হয়
    private val gambleHosts = hashSetOf(
        "1xbet.com", "1xbet.bd", "1xbet.in", "1xlite.com", "1xbit.com", "1xbetbd.com", "melbet.com", "melbet.bd", "mostbet.com", "mostbet.in", "mostbet-bd.com",
        "betwinner.com", "parimatch.com", "parimatch.in", "megapari.com", "linebet.com", "1win.com", "1win.io", "1win.pro", "bet365.com", "22bet.com",
        "betway.com", "dafabet.com", "fun88.com", "stake.com", "bc.game", "rollbit.com", "roobet.com", "pin-up.casino", "pinup.bet", "pin-up.bet",
        "batery.com", "baji999.com", "baji.com", "jeetbuzz.com", "crickex.com", "betvisa.com", "krikya.com", "nagad88.com", "marvelbet.com", "bluechip.io",
        "betfair.com", "williamhill.com", "888casino.com", "unibet.com", "ladbrokes.com", "paddypower.com", "draftkings.com", "fanduel.com",
        "betmgm.com", "caesars.com.sportsbook", "bovada.lv", "betonline.ag", "mybookie.ag", "sportsbetting.ag", "pokerstars.com", "partypoker.com",
        "lucky-jet.com", "aviator-game.com", "spribe.co", "pragmaticplay.com", "slotsmillion.com", "royalpanda.com", "jackpotcity.com", "spinpalace.com",
        "casumo.com", "leovegas.com", "mrgreen.com", "betsson.com", "bwin.com", "betano.com", "betfred.com", "coral.co.uk", "skybet.com", "10bet.com",
        "vulkanvegas.com", "vulkan-vegas.com", "casinox.com", "joycasino.com", "gginbet.com", "betpawa.com", "sportybet.com", "betking.com", "bet9ja.com"
    )
    // হোস্টের নামে এই শব্দ থাকলেই জুয়ার সাইট ধরা হয় (ভুল ধরা কমাতে শুধু নির্দিষ্ট ব্র্যান্ড/শব্দ)
    private val gambleTokens = listOf(
        "1xbet", "1xlite", "1xbit", "melbet", "mostbet", "betwinner", "parimatch", "megapari", "linebet", "bet365", "22bet", "dafabet",
        "casino", "sportsbook", "betting", "gambling", "jackpot", "pinup", "pin-up", "1win", "batery", "jeetbuzz", "crickex", "baji", "krikya",
        "lucky-jet", "luckyjet", "aviator-bet", "megaslot", "slot88", "slotgacor", "togel", "sbobet", "joker123", "poker88"
    )
    @Volatile var blocked = 0

    private fun inSet(set: Set<String>, host: String?): Boolean {
        var h = host?.lowercase() ?: return false
        while (true) { if (set.contains(h)) return true; val i = h.indexOf('.'); if (i < 0) return false; h = h.substring(i + 1) }
    }
    fun isAd(host: String?): Boolean = inSet(hosts, host)
    fun isGambling(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        if (inSet(gambleHosts, h)) return true
        return gambleTokens.any { h.contains(it) }
    }

    // রিকোয়েস্টের পাথ দেখেও ধরা (YouTube-এর অ্যাড রিকোয়েস্ট, গুগল অ্যাড ইত্যাদি)
    fun isAdUrl(u: Uri): Boolean {
        val h = (u.host ?: return false).lowercase()
        if (isAd(h)) return true
        val p = u.path ?: ""
        if (h == "youtube.com" || h.endsWith(".youtube.com") || h.endsWith("youtube-nocookie.com")) {
            if (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads") || p.startsWith("/ptracking") || p.contains("/get_midroll_") ||
                p.startsWith("/api/stats/qoe") && (u.getQueryParameter("adformat") != null)) return true
            if (u.getQueryParameter("adformat") != null || u.getQueryParameter("ad_type") != null) return true
        }
        if (h.endsWith("googlevideo.com") && (u.getQueryParameter("oad") != null || u.getQueryParameter("adformat") != null)) return true
        if (p.contains("/pagead/") || p.endsWith("/adsbygoogle.js") || p.contains("/pubads_impl") || p.endsWith("/show_ads_impl.js")) return true
        return false
    }

    const val YT_CSS = "#masthead-ad,#player-ads,#panels ytd-ads-engagement-panel-content-renderer,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-display-ad-renderer," +
        "ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,ytd-banner-promo-renderer,ytd-statement-banner-renderer,ytd-primetime-promo-renderer," +
        "ytd-player-legacy-desktop-watch-ads-renderer,ytd-companion-slot-renderer,ytd-action-companion-ad-renderer,ytd-engagement-panel-section-list-renderer[target-id='engagement-panel-ads']," +
        ".ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ce-element-show.ytp-ad,.video-ads," +
        "ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-statement-banner-renderer,ytm-ad-slot-renderer,ytm-in-feed-ad-layout-renderer," +
        "ad-slot-renderer,.ad-div,.ytm-ad-slot,.mobile-topbar-ad,[class*='ytp-ad-'][class*='overlay']{display:none!important}"

    const val CSS = "ins.adsbygoogle,.adsbygoogle,[id^='google_ads'],[id^='div-gpt-ad'],iframe[src*='doubleclick'],iframe[src*='googlesyndication'],iframe[id^='google_ads']," +
        ".ad-banner,.ad-container,.ad-slot,.advert,.advertisement,[class*='sponsored-ad'],[id*='taboola'],[class*='taboola'],[id*='outbrain'],[class*='outbrain']," +
        "[id^='aswift_'],[id^='ad_unit'],[id^='ad-slot'],[class^='adsbox'],.adsbox,.ad-wrapper,.ads-wrapper,.banner-ads,.sticky-ad,.adthrive,[id*='adthrive'],[class*='mgid'],[id*='mgid']," +
        "iframe[src*='adsterra'],iframe[src*='exoclick'],iframe[src*='propeller'],iframe[src*='popads'],iframe[src*='monetag']," +
        // জুয়ার বিজ্ঞাপন: ব্যানার/ইফ্রেম/লিংক যেগুলো এই ব্র্যান্ডের দিকে যায়
        "a[href*='1xbet.'],a[href*='1xlite.'],a[href*='melbet.'],a[href*='mostbet.'],a[href*='betwinner.'],a[href*='parimatch.'],a[href*='megapari.'],a[href*='linebet.']," +
        "a[href*='1win.'],a[href*='bet365.'],a[href*='22bet.'],a[href*='pin-up.'],a[href*='pinup.'],a[href*='batery.'],a[href*='jeetbuzz.'],a[href*='crickex.'],a[href*='baji999.'],a[href*='krikya.']," +
        "iframe[src*='1xbet'],iframe[src*='melbet'],iframe[src*='mostbet'],iframe[src*='betwinner'],iframe[src*='parimatch'],iframe[src*='megapari'],iframe[src*='linebet'],iframe[src*='casino']," +
        "iframe[src*='1win'],iframe[src*='pin-up'],iframe[src*='sportsbook']{display:none!important}"

    private fun styleJs(css: String) = "var s=document.createElement('style');s.textContent=\"" + css.replace("\"", "\\\"") + "\";(document.head||document.documentElement).appendChild(s);"

    // পেজ লোড শেষে চলে: সাধারণ বিজ্ঞাপন লুকানো
    val JS = "(function(){if(window.__sajidCss)return;window.__sajidCss=1;" + styleJs(CSS) + "})();"

    // পেজ শুরুর আগেই চলে (addDocumentStartJavaScript): CSS + YouTube অ্যাড কাটা + পপআপ/রিডাইরেক্ট অ্যাড আটকানো
    val START_JS = """
(function(){
  if (window.__sajidAdStart) return; window.__sajidAdStart = 1;
  try{ if (window.BAd && !window.BAd.on()) return; }catch(e){}
  var host = location.hostname;
  function addCss(css){ try{ var s=document.createElement('style'); s.textContent=css; (document.head||document.documentElement).appendChild(s);}catch(e){} }
  addCss(__CSS__);
  var isYt = /(^|\.)youtube(-nocookie)?\.com${'$'}/.test(host);
  if (isYt) {
    addCss(__YTCSS__);
    var KEYS = ['adPlacements','playerAds','adSlots','adBreakParams','adBreakHeartbeatParams'];
    function clean(o){
      try{
        if (o && typeof o === 'object') {
          for (var i=0;i<KEYS.length;i++){ if (KEYS[i] in o) { try{ delete o[KEYS[i]]; }catch(e){ o[KEYS[i]] = undefined; } } }
          if (o.playerResponse) clean(o.playerResponse);
        }
      }catch(e){}
      return o;
    }
    // ইনিশিয়াল প্লেয়ার ডেটা থেকে অ্যাড তথ্য বাদ
    try{
      var _ipr; Object.defineProperty(window,'ytInitialPlayerResponse',{configurable:true,get:function(){return _ipr;},set:function(v){_ipr=clean(v);}});
    }catch(e){}
    try{
      var _id; Object.defineProperty(window,'ytInitialData',{configurable:true,get:function(){return _id;},set:function(v){ try{ if(v&&v.contents) cleanFeed(v);}catch(e){} _id=v;}});
    }catch(e){}
    function cleanFeed(o){ /* ফিডের ভিতরের অ্যাড স্লট CSS দিয়ে লুকানো হয়; এখানে শুধু মূল অ্যাড কী মোছা */ clean(o); }
    // JSON.parse + fetch/XHR এর রেসপন্স
    var jp = JSON.parse;
    JSON.parse = function(){ var r = jp.apply(this, arguments); try{ if (r && typeof r==='object' && (r.adPlacements||r.playerAds||r.adSlots||r.playerResponse)) clean(r);}catch(e){} return r; };
    try{
      var rj = Response.prototype.json;
      Response.prototype.json = function(){ return rj.apply(this, arguments).then(function(r){ try{ clean(r);}catch(e){} return r; }); };
    }catch(e){}
    try{
      var rt = Response.prototype.text;
      Response.prototype.text = function(){ return rt.apply(this, arguments).then(function(t){
        try{ if (typeof t==='string' && (t.indexOf('"adPlacements"')>-1 || t.indexOf('"playerAds"')>-1 || t.indexOf('"adSlots"')>-1) && t.charAt(0)==='{') { var o = jp.call(JSON, t); clean(o); return JSON.stringify(o); } }catch(e){}
        return t; }); };
    }catch(e){}
    try{
      var xd = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype,'responseText');
      if (xd && xd.get) Object.defineProperty(XMLHttpRequest.prototype,'responseText',{configurable:true,get:function(){
        var t = xd.get.call(this);
        try{ if (typeof t==='string' && (t.indexOf('"adPlacements"')>-1 || t.indexOf('"playerAds"')>-1) && t.charAt(0)==='{') { var o = jp.call(JSON, t); clean(o); return JSON.stringify(o); } }catch(e){}
        return t; }});
    }catch(e){}
    // অ্যাড চলে এলে সাথে সাথে স্কিপ / শেষে পাঠানো
    var mutedByUs = false;
    function tick(){
      try{
        var p = document.querySelector('.html5-video-player');
        var ad = (p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting'))) || !!document.querySelector('.ytp-ad-player-overlay,.ytp-ad-player-overlay-layout,.ytp-ad-preview-container,.ytp-ad-text');
        var v = document.querySelector('video.html5-main-video') || document.querySelector('video');
        if (ad) {
          if (v) {
            if (!v.muted) { v.muted = true; mutedByUs = true; }
            if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.2) { try{ v.currentTime = v.duration; }catch(e){} }
            try{ v.playbackRate = 16; }catch(e){}
          }
          var b = document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button,button.ytp-ad-skip-button-modern');
          if (b) b.click();
        } else if (mutedByUs && v) { v.muted = false; mutedByUs = false; try{ v.playbackRate = 1; }catch(e){} }
        var c = document.querySelector('.ytp-ad-overlay-close-button'); if (c) c.click();
        var d = document.querySelector('ytd-enforcement-message-view-model,tp-yt-paper-dialog.ytd-popup-container ytd-enforcement-message-view-model');
        if (d) { var btn = document.querySelector('#dismiss-button,yt-button-renderer#dismiss-button button'); if (btn) btn.click(); var vv=document.querySelector('video'); if (vv && vv.paused) { try{ vv.play(); }catch(e){} } }
      }catch(e){}
    }
    setInterval(tick, 400);
  }
  // ছদ্মবেশী পপআপ / ট্যাব-আন্ডার অ্যাড: ইউজার ক্লিক ছাড়া window.open বন্ধ
  try{
    var lastTouch = 0;
    ['touchstart','mousedown','keydown','click'].forEach(function(t){ window.addEventListener(t,function(e){ if (e.isTrusted) lastTouch = Date.now(); },true); });
    var wo = window.open;
    window.open = function(){ if (Date.now() - lastTouch > 4000) { return null; } return wo.apply(window, arguments); };
  }catch(e){}
})();
"""
    fun startScript(): String = START_JS.replace("__CSS__", jsStr(CSS)).replace("__YTCSS__", jsStr(YT_CSS))
    private fun jsStr(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\""
}
